from urllib.parse import urlencode, parse_qsl, urlparse, unquote
from functools import partial
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from concurrent.futures import ThreadPoolExecutor
from calendar import timegm
from time import strftime, strptime, mktime, gmtime, localtime
from json import loads
import re, sys, os, urlquick, xbmcgui
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
addon_id = Addon().getAddonInfo('id')
ICON = Addon().getAddonInfo('icon')
UA = 'Mozilla/5.0 (Linux; Android 15; Pixel 9 Pro Build/AP4A.241212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/605.1.15 EdgA/133.0.0.0'
def addDir(title, mode, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': ICON, 'thumb': ICON, 'poster': ICON, 'fanart': ICON})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(title)
    setContent(HANDLE, 'videos')
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref, luu):
    r = urlquick.get(url, timeout=30, max_age=luu, headers={'user-agent': UA,'referer': ref.encode('utf-8')}, verify=False)
    r.encoding = 'utf-8'
    return r
def domain(url):
    parsed_url = urlparse(url.strip())
    return f'{parsed_url.scheme}://{parsed_url.netloc}'
def ct(initial_time):
    struct_time = strptime(initial_time, '%Y-%m-%d %H:%M:%S')
    timestamp = mktime(struct_time) + (7 * 3600)
    new_time = strftime('%H:%M', localtime(timestamp))
    return new_time
def get_i():
    ts = timegm(gmtime())
    return getlink(f'https://embed.plcdn.xyz/gf/data/bf_vn_nt.js?{ts}', 'https://embed.plcdn.xyz/', 400)
def get_l():
    return getlink(f'https://tvlive.api-football.xyz/tvlive_vn_fb.txt', 'https://embed.plcdn.xyz/', 400)
def inf():
    with ThreadPoolExecutor(2) as ex:
        f1 = ex.submit(get_i)
        f2 = ex.submit(get_l)
    return (f1.result(),f2.result())
def main():
    resp1, resp2 = inf()
    r1 = resp1.text
    ids = re.finditer(r'[$!](\d+)', resp2.text)
    for m in ids:
        try:
            k = m[1]
            match = re.search(rf"{k}.*?'(.*?)'.*?'(.*?)'.*?'(.*?)'.*?\,.*?\,(.*?)\,", r1)
            if match and int(match[4]) >= 0:
                ten = f'{ct(match[3])} {match[1]} vs {match[2]}'
                addDir(ten, 'list_91phut', k=k, t=ten)
        except:
            pass
    endOfDirectory(HANDLE)
def list_91phut(k, t):
    r = get_l()
    if k in r.text:
        match = re.search(rf'{k}(.*?)\!', r.text)
        ids = re.finditer(r'(https://.*?)\^', match[1])
        for dem, m in enumerate(ids, start=1):
            ten = f'{t} #{dem}'
            addDir(ten, 'sv_91phut', k=m[1], t=t)
    endOfDirectory(HANDLE)
def sv_91phut(url, name):
    resp = getlink(url, url, 400)
    if 'link-video' in resp.text:
        soup = resp.parse().iterfind('.//div[@class="link-video"]//a')
        for k in soup:
            ten = ''.join(k.itertext()).strip()
            ep = k.get('href')
            addDir(f'{name} | {ten}', 'ifr_bongda', ep = ep, t=name, is_folder=False)
    elif 'tv_links' in resp.text:
        soup = resp.parse().iterfind('.//div[@id="tv_links"]//a')
        for k in soup:
            ten = ''.join(k.itertext()).strip()
            ep = k.get('href')
            addDir(f'{name} | {ten}', 'ifr_bongda', ep = ep, t=name, is_folder=False)
    else:
        addDir(name, 'ifr_bongda', ep = url, t=name, is_folder=False)
    endOfDirectory(HANDLE)
def ifr_bongda(url):
    resp = getlink(url, url, -1)
    m = re.search(r'var stream_urls.*?"(.*?)"', resp.text)
    ifr = loads(f'"{m[1]}"')
    r = getlink(ifr, url, -1)
    linkstream = re.search(r'(https?://[^\s"]+\.m3u8[^"\']*)', r.text)[1]
    linkplay = re.sub(r'\s+', '%20', linkstream.strip(), flags=re.UNICODE)
    hdr = f"verifypeer=false&User-Agent={unquote(UA)}&Referer={domain(ifr)}/"
    play_item = xbmcgui.ListItem(offscreen=True)
    if any((re.search(r':(?!/)', linkplay), ('?' in linkplay))):
        linkplay += f'|{hdr}'
    else:
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
        play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
    play_item.setPath(linkplay)
    setResolvedUrl(HANDLE, True, listitem=play_item)
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action_map = {
        'list_91phut': partial(list_91phut, params.get('k'), params.get('t')),
        'sv_91phut': partial(sv_91phut, params.get('k'), params.get('t')),
        'ifr_bongda': partial(ifr_bongda, params.get('ep')),
    }
    action_map.get(params.get('mode'), main)()
try:
    router(sys.argv[2][1:])
except:
    pass