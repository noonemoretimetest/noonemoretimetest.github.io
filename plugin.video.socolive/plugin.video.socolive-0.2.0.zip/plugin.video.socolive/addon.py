from urllib.parse import urlencode, parse_qsl
from functools import partial
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from json import loads
from datetime import datetime
from calendar import timegm
from time import gmtime
from xbmcgui import ListItem
from requests import Session
from sys import argv
import re
addon_url = argv[0]
HANDLE = int(argv[1])
ICON = Addon().getAddonInfo('icon')
UA = 'Mozilla/5.0 (SMART-TV; LINUX; Tizen 9.0) AppleWebKit/537.36 (KHTML, like Gecko) 120.0.6099.5/9.0 TV Safari/537.36'
timestamp = timegm(gmtime())
def addDir(title, mode, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = ListItem(label=f'{title}')
    list_item.setArt({'icon': ICON, 'thumb': ICON, 'poster': ICON, 'fanart': ICON})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(f'{title}')
    info_tag.setPlot(f'{title}')
    setContent(HANDLE, 'videos')
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url):
    with Session() as s:
        s.headers.update({'user-agent': UA,'referer': url.encode('utf-8')})
        try:
            r = s.get(url, timeout=20)
        except:
            r = s.get(url, timeout=20, verify=False)
    r.encoding = 'utf-8'
    return r
def main():
    addDir('Đang trực tiếp', 'live_socolive')
    u = f'https://json.vnres.co/matches.json?v={timestamp}'
    resp = getlink(u)
    nd = re.search(r'(\{.*\})', resp.text, re.DOTALL)[1]
    m = loads(nd)
    mh = m['data']['0']
    for k in mh:
        tg = datetime.fromtimestamp(int(k['matchTime'])/1000).strftime('%H:%M')
        tenm = f"{tg} {k['hostName']} vs {k['guestName']}"
        addDir(tenm, 'list_socolive', idv = k['scheduleId'], name=tenm)
    endOfDirectory(HANDLE)
def list_socolive(idv, name):
    u = f'https://json.vnres.co/matches.json?v={timestamp}'
    resp = getlink(u)
    nd = re.search(r'(\{.*\})', resp.text, re.DOTALL)[1]
    m = loads(nd)
    mh = m['data']['0']
    for k in mh:
        for l in k['anchors']:
            if k['scheduleId'] == int(idv):
                tenm = f"{name} | {l['nickName']}"
                addDir(tenm, 'play', id = l['anchor']['roomNum'], is_folder=False)
    endOfDirectory(HANDLE)
def live_socolive():
    u = f'http://json.vnres.co/all_live_rooms.json?v={timestamp}'
    resp = getlink(u)
    nd = re.search(r'(\{.*\})', resp.text, re.DOTALL)[1]
    m = loads(nd)
    mh = m['data']['hot']
    for k in mh:
        tenm = f'{k["title"]} | {k["anchor"]["nickName"]}'
        addDir(tenm, 'play', id = k['roomNum'], is_folder=False)
    endOfDirectory(HANDLE)
def play(idp):
    url = f'https://json.vnres.co/room/{idp}/detail.json?v={timestamp}'
    r = getlink(url)
    nd = re.search(r'(\{.*\})', r.text, re.DOTALL)[1]
    linkplay = loads(nd)['data']['stream']['hdFlv']
    linkplay = re.sub(r'\s+', '%20', linkplay.strip(), flags=re.UNICODE)
    play_item = ListItem(offscreen=True, path=linkplay)
    setResolvedUrl(HANDLE, True, listitem=play_item)
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action_map = {
        'list_socolive': partial(list_socolive, params.get('idv'), params.get('name')),
        'live_socolive': live_socolive,
        'play': partial(play, params.get('id')),
    }
    action_map.get(params.get('mode'), main)()
try:
    router(argv[2][1:])
except:
    pass