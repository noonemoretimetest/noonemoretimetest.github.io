from urllib.parse import urlencode, parse_qsl, quote_plus, urlparse
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from pickle import load, dump
from xbmcvfs import translatePath
import re, sys, requests, xbmcgui, json, os
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
addon_name = Addon().getAddonInfo('name')
addon_id = Addon().getAddonInfo('id')
mediaf = Addon().getAddonInfo('path') + '/media/'
searchimg = mediaf + 'search.png'
fallback_url = mediaf + 'nolink.mp4'
addon_data_dir = os.path.join(translatePath('special://userdata/addon_data'), addon_id)
def addDir(title, img, img2, plot, mode, is_folder=True, **kwargs):
    kwargs = {key: json.dumps(value) if isinstance(value, list) else value for key, value in kwargs.items()}
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': img, 'thumb': img, 'poster': img, 'fanart': img2})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(plot)
    setContent(HANDLE, 'videos')
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def get_file_path(filename):
    return os.path.join(addon_data_dir, filename)
def read_file(filename):
    path = get_file_path(filename)
    if not os.path.exists(path):
        return None
    try:
        with open(path, 'rb') as f:
            return load(f)
    except:
        return None
def write_file(filename, data):
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)
    path = get_file_path(filename)
    try:
        with open(path, 'wb') as f:
            dump(data, f)
    except:
        pass
    return path
def search_history_save(search_key):
    if not search_key:
        return
    history = read_file('historys.pkl') or []
    if search_key in history:
        history.remove(search_key)
    elif len(history) >= 20:
        history.pop()
    history.insert(0, search_key)
    write_file('historys.pkl', history)
def search_history_get():
    return read_file('historys.pkl') or []
def find(params_url):
    addDir('Tìm kiếm', searchimg, searchimg, 'Tìm kiếm', 'search', link=params_url)
    b = search_history_get()
    if b:
        for m in b:
            addDir(m, searchimg, searchimg, m, 'timdetail', link=params_url, key = m)
    endOfDirectory(HANDLE)
def readjs(u):
    r = requests.get(u, timeout=20, headers={'user-agent': 'Mozilla/5.0 (Linux; Android 16; Pixel 9 Pro Build/AP4A.261212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/605.1.15 EdgA/140.0.0.0','referer': u.encode('utf-8')})
    r.encoding = 'utf-8'
    js = r.json()
    for k in js:
        name = k['name']
        link = k['link']
        poster = k['poster']
        background = k['background']
        description = k['description']
        if k.get('search'):
            addDir(name, searchimg, background, description, 'timkiem', link=link)
        elif k.get('folder'):
            addDir(name, poster, background, description, 'index_xemplay', link=link)
        else:
            mode = 'playinputstream' if k.get('inputstream') else 'play'
            kwargs = {
                'link': link,
                'is_folder': False
            }
            if k.get('headers'):
                kwargs['headers'] = k['headers']
            addDir(name, poster, background, description, mode, **kwargs)
    endOfDirectory(HANDLE)
def timkiem(query, params_url):
    search_query = quote_plus(query)
    readjs(f'{params_url}{search_query}')
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if not params:
        readjs('https://api.npoint.io/e6752bd0d7482e73d6e8')
    elif params['mode'] == 'index_xemplay':
        readjs(params['link'])
    elif params['mode'] =='search':
        params_url = params['link']
        query = xbmcgui.Dialog().input(u'Nhập nội dung cần tìm ...', type=xbmcgui.INPUT_ALPHANUM)
        if query:
            search_history_save(query)
            timkiem(query, params_url)
        else:
            find(params_url)
    elif params['mode'] =='timkiem':
        find(params['link'])
    elif params['mode'] =='timdetail':
        timkiem(params['key'], params['link'])
    elif params['mode'] == 'playinputstream':
        play_item = xbmcgui.ListItem(offscreen=True)
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setPath(params['link'])
        if params.get('headers'):
            hdr = params['headers']
            play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
            play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
        setResolvedUrl(HANDLE, True, listitem=play_item)
    elif params['mode'] == 'play':
        linkplay = params['link']
        play_item = xbmcgui.ListItem(offscreen=True)
        if params.get('headers'):
            hdr = params['headers']
            linkplay = f'{linkplay}|{hdr}'
        play_item.setPath(linkplay)
        setResolvedUrl(HANDLE, True, listitem=play_item)
try:
    router(sys.argv[2][1:])
except:
    pass