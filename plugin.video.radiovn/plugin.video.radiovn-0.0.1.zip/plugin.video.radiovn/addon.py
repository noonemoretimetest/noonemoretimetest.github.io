from urllib.parse import urlencode, parse_qsl, unquote
from functools import partial
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
import re, sys, xbmcgui, requests
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
ICON = Addon().getAddonInfo('icon')
uthethao = 'https://raw.githubusercontent.com/luongtamlong/DAKLAK_RADIO/refs/heads/main/Radio.m3u'
UA = 'Mozilla/5.0 (Linux; Android 16; Pixel 9 Pro Build/AP4A.261212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/605.1.15 EdgA/140.0.0.0'
def getlink(url):
    r = requests.get(url, timeout=20, headers={'user-agent': UA,'referer': url.encode('utf-8')})
    r.encoding = 'utf-8'
    return r
def addDir(title, img, mode, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=f'{title}')
    list_item.setArt({'icon': img, 'thumb': img, 'poster': img, 'fanart': img})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(f'{title}')
    info_tag.setPlot(f'{title}')
    setContent(HANDLE, 'videos')
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
class m3u:
    @staticmethod
    def convert(m3u_file: str):
        m3u_json = []
        lines = m3u_file.split("\n")
        i = 0
        while i < len(lines):
            line = lines[i]
            if line.startswith("#EXTINF"):
                channelInfo = {}
                try:
                    logoStartIndex = line.index('tvg-logo="') + 10
                    logoEndIndex = line.index('"', logoStartIndex)
                    logoUrl = line[logoStartIndex:logoEndIndex]
                except ValueError:
                    logoUrl = ""
                try:
                    groupTitleStartIndex = line.index('group-title="') + 13
                    groupTitleEndIndex = line.index('"', groupTitleStartIndex)
                    groupTitle = line[groupTitleStartIndex:groupTitleEndIndex]
                except ValueError:
                    groupTitle = ""
                titleStartIndex = line.rindex(",") + 1
                title = line[titleStartIndex:].strip() if "," in line else ""
                j = i + 1
                link = ""
                user_agent = ""
                referrer = ""
                while j < len(lines) and lines[j].startswith("#"):
                    if lines[j].startswith("#EXTVLCOPT:http-user-agent="):
                        user_agent = lines[j].split("=", 1)[1].strip()
                    elif lines[j].startswith("#EXTVLCOPT:http-referrer="):
                        referrer = lines[j].split("=", 1)[1].strip()
                    j += 1
                if j < len(lines):
                    link = lines[j].strip()
                channelInfo["tvg-logo"] = logoUrl
                channelInfo["group-title"] = groupTitle
                channelInfo["title"] = title
                channelInfo["link"] = link
                if user_agent:
                    channelInfo["user-agent"] = user_agent
                if referrer:
                    channelInfo["referrer"] = referrer
                m3u_json.append(channelInfo)
            i += 1
        return m3u_json
def main():
    m3u_json = m3u.convert(getlink(uthethao).text)
    ld = []
    seen = set()
    for k in m3u_json:
        nhom = k['group-title']
        if nhom not in seen:
            seen.add(nhom)
            ld.append(nhom)
    for k in ld:
        addDir(k, ICON, 'group', nhom = k)
    endOfDirectory(HANDLE)
def group(nhom):
    m3u_json = m3u.convert(getlink(uthethao).text)
    for k in m3u_json:
        if nhom == k['group-title']:
            logo = k.get('tvg-logo', ICON)
            name = k['title'].strip()
            link = k['link']
            user_agent = k.get('user-agent')
            referrer = k.get('referrer')
            addDir(name, logo, 'play', id = link, UA=user_agent, ref=referrer, is_folder=False)
    endOfDirectory(HANDLE)
def play(idp, UA, ref):
    linkplay = re.sub(r'\s+', '%20', idp.strip(), flags=re.UNICODE)
    play_item = xbmcgui.ListItem(offscreen=True)
    if '.m3u8' in linkplay:
        hdr = f'verifypeer=false&User-Agent={unquote(UA)}'
        if ref:
            hdr += f'&Referer={ref}'
        linkplay = f"{linkplay}|verifypeer=false&User-Agent={unquote(UA)}&Referer={ref}"
        play_item.setPath(f'{linkplay}|{hdr}')
    play_item.setPath(linkplay)
    setResolvedUrl(HANDLE, True, listitem=play_item)
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action_map = {
        'group': partial(group, params.get('nhom')),
        'play': partial(play, params.get('id'), params.get('UA'), params.get('ref')),
    }
    action_map.get(params.get('mode'), main)()
try:
    router(sys.argv[2][1:])
except:
    pass