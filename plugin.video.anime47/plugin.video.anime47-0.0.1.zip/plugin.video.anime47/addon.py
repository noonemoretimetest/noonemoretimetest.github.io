from urllib.parse import urlencode, parse_qsl, unquote, quote_plus, urlparse, urljoin
from functools import partial
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from pickle import load, dump
from json import loads
from xbmcvfs import translatePath
from htmlement import fromstring
from base64 import b64decode
from hashlib import md5
from time import localtime
from Cryptodome.Cipher import AES
import re, sys, os, requests, xbmcgui
uanm47 = 'https://anime47.com'
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
addon_id = Addon().getAddonInfo('id')
ICON = Addon().getAddonInfo('icon')
PATH = Addon().getAddonInfo('path')
RESOURCES = PATH + '/media/'
searchimg = RESOURCES +'search.png'
nextimg = RESOURCES + 'next.png'
UA = 'Mozilla/5.0 (Linux; Android 16; Pixel 9 Pro Build/AP4A.261212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/605.1.15 EdgA/140.0.0.0'
addon_data_dir = os.path.join(translatePath('special://userdata/addon_data'), addon_id)
def addDir(title=None, img=None, plot=None, mode=None, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=f'{title}')
    list_item.setArt({'icon': img, 'thumb': img, 'poster': img, 'fanart': img})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(f'{title}')
    info_tag.setPlot(f'{plot}')
    setContent(HANDLE, 'videos')
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref):
    r = requests.get(url, timeout=30, headers={'user-agent': UA,'referer': ref.encode('utf-8')})
    r.encoding = 'utf-8'
    return r
def domhtml(root, xpath, attribute=None, default=None):
    element = root.find(xpath)
    return default if element is None else element.get(attribute, '\n'.join(element.itertext()).strip())
def referer(url):
    parsed_url = urlparse(url.strip())
    return f'{parsed_url.scheme}://{parsed_url.netloc}/'
def get_file_path(filename):
    return os.path.join(addon_data_dir, filename)
def read_file(filename):
    path = get_file_path(filename)
    if not os.path.exists(path):
        return None
    try:
        with open(path, 'rb') as f:
            return load(f)
    except:
        return None
def write_file(filename, data):
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)
    path = get_file_path(filename)
    try:
        with open(path, 'wb') as f:
            dump(data, f)
    except:
        pass
    return path
def search_history_save(search_key):
    if not search_key:
        return
    history = read_file('historys.pkl') or []
    if search_key in history:
        history.remove(search_key)
    elif len(history) >= 20:
        history.pop()
    history.insert(0, search_key)
    write_file('historys.pkl', history)
def search_history_get():
    return read_file('historys.pkl') or []
def decrypt_cryptojs_aes(json_input, passphrase):
    j = loads(json_input)
    ct = b64decode(j['ct'])
    iv = bytes.fromhex(j['iv'])
    salt = bytes.fromhex(j['s'])
    key_size = 32
    iterations = 1
    key_iv = b''
    last = b''
    while len(key_iv) < (key_size + 16):
        last = md5(last + passphrase.encode('utf-8') + salt).digest()
        key_iv += last
    key = key_iv[:key_size]
    iv = key_iv[key_size:key_size+16]
    cipher = AES.new(key, AES.MODE_CBC, iv)
    decrypted = cipher.decrypt(ct)
    pad_len = decrypted[-1]
    plaintext = decrypted[:-pad_len]
    return plaintext.decode('utf-8')
def get_season_code(month, day):
    if (month == 12 and day >= 21) or (1 <= month <= 3) or (month == 3 and day < 20):
        return 4
    elif (month == 3 and day >= 20) or (4 <= month <= 5) or (month == 6 and day < 21):
        return 5
    elif (month == 6 and day >= 21) or (7 <= month <= 8) or (month == 9 and day < 23):
        return 6
    elif (month == 9 and day >= 23) or (10 <= month <= 11) or (month == 12 and day < 21):
        return 7
def get_seasons():
    now = localtime()
    year = now.tm_year
    month = now.tm_mon
    day = now.tm_mday
    current_season = get_season_code(month, day)
    current_year = year
    if current_season == 5:
        previous_season = 4
        previous_year = year - 1
    else:
        previous_season = current_season - 1 if current_season > 4 else 7
        previous_year = year
    return (current_season, current_year), (previous_season, previous_year)
def main():
    addDir('Tìm kiếm', searchimg, 'Tìm kiếm', 'timkiem')
    T = {'Thể loại': 'anime47_theloai',
        'Trạng thái': 'anime47_trangthai',
        'Xem nhiều': 'anime47_xemnhieu',
        'Bình luận nhiều': 'anime47_binhluannhieu',
        'Lưỡng long nhất thể': 'anime47_luonglongnhatthe',
        'Năm': 'anime47_nam'
        }
    dulieu = {
        'Phim mới': f'{uanm47}/danh-sach/phim-moi/',
        'Mùa này': f'{uanm47}/danh-sach/anime-mua-moi-update.html/',
        'Mùa trước': f'{uanm47}/danh-sach/anime-mua-truoc-moi-update.html/',
        'Bộ cũ': f'{uanm47}/danh-sach/anime-cu-moi-update.html/',
        'Hoạt hình Trung Quốc': f'{uanm47}/the-loai/hoat-hinh-trung-quoc-75/',
        'Phim dạng người đóng': f'{uanm47}/danh-sach/jpdrama/'
        }
    for b in T:
        addDir(b, ICON, b, T[b])
    for k in dulieu:
        addDir(k, ICON, k, 'ds_anime47', url = dulieu[k], p=1)
    endOfDirectory(HANDLE)
def find():
    addDir('Tìm kiếm', searchimg, 'Tìm kiếm', 'search')
    b = search_history_get()
    if b:
        for m in b:
            addDir(m, searchimg, m, 'timanime47', key = m)
    endOfDirectory(HANDLE)
def timkiem(query):
    sr = quote_plus(query)
    url = f'{uanm47}/tim-nang-cao/?keyword={sr}&nam=&season=&status=&sapxep=1'
    ds_anime47(url, 1)
def anime47_theloai():
    dulieu = {
        'Đời Thường': f'{uanm47}/the-loai/doi-thuong-38/',
        'Harem': f'{uanm47}/the-loai/harem-36/',
        'Shounen': f'{uanm47}/the-loai/shounen-35/',
        'Học Đường': f'{uanm47}/the-loai/hoc-duong-33/',
        'Thể Thao': f'{uanm47}/the-loai/the-thao-32/',
        'Drama': f'{uanm47}/the-loai/drama-31/',
        'Trinh Thám': f'{uanm47}/the-loai/trinh-tham-30/',
        'Kinh Dị': f'{uanm47}/the-loai/kinh-di-29/',
        'Mecha': f'{uanm47}/the-loai/mecha-28/',
        'Phép Thuật': f'{uanm47}/the-loai/phep-thuat-27/',
        'Phiêu Lưu': f'{uanm47}/the-loai/phieu-luu-26/',
        'Ecchi': f'{uanm47}/the-loai/ecchi-25/',
        'Hài Hước': f'{uanm47}/the-loai/hai-huoc-24/',
        'Hành Động': f'{uanm47}/the-loai/hanh-dong-23/',
        'Romance': f'{uanm47}/the-loai/romance-40/',
        'Lịch Sử': f'{uanm47}/the-loai/lich-su-41/',
        'Âm Nhạc': f'{uanm47}/the-loai/am-nhac-42/',
        'Tokusatsu': f'{uanm47}/the-loai/tokusatsu-43/',
        'Viễn Tưởng': f'{uanm47}/the-loai/vien-tuong-44/',
        'Fantasy': f'{uanm47}/the-loai/fantasy-45/',
        'Blu-ray': f'{uanm47}/the-loai/blu-ray-46/',
        'Game': f'{uanm47}/the-loai/game-48/',
        'Shoujo': f'{uanm47}/the-loai/shoujo-49/',
        'Seinen': f'{uanm47}/the-loai/seinen-50/',
        'Super Power': f'{uanm47}/the-loai/super-power-51/',
        'Space': f'{uanm47}/the-loai/space-52/',
        'Martial Arts': f'{uanm47}/the-loai/martial-arts-53/',
        'Siêu Nhiên': f'{uanm47}/the-loai/sieu-nhien-54/',
        'Vampire': f'{uanm47}/the-loai/vampire-55/',
        'Mystery': f'{uanm47}/the-loai/mystery-56/',
        'Psychological': f'{uanm47}/the-loai/psychological-57/',
        'Yuri': f'{uanm47}/the-loai/yuri-58/',
        'Shounen Ai': f'{uanm47}/the-loai/shounen-ai-59/',
        'Shoujo Ai': f'{uanm47}/the-loai/shoujo-ai-60/',
        'Josei': f'{uanm47}/the-loai/josei-61/',
        'Parody': f'{uanm47}/the-loai/parody-62/',
        'Coming of Age': f'{uanm47}/the-loai/coming-of-age-63/',
        'Tragedy': f'{uanm47}/the-loai/tragedy-64/',
        'Demons': f'{uanm47}/the-loai/demons-65/',
        'Car': f'{uanm47}/the-loai/car-66/',
        'Dementia': f'{uanm47}/the-loai/dementia-67/',
        'Hentai': f'{uanm47}/the-loai/hentai-68/',
        'Kid': f'{uanm47}/the-loai/kid-69/',
        'Military': f'{uanm47}/the-loai/military-70/',
        'Police': f'{uanm47}/the-loai/police-71/',
        'Samurai': f'{uanm47}/the-loai/samurai-72/',
        'Thriller': f'{uanm47}/the-loai/thriller-73/',
        'Yaoi': f'{uanm47}/the-loai/yaoi-74/',
        'Hoạt hình Trung Quốc': f'{uanm47}/the-loai/hoat-hinh-trung-quoc-75/',
        'Xuyên Không - Chuyển Kiếp': f'{uanm47}/the-loai/xuyen-khong-chuyen-kiep-76/'
        }
    for k in dulieu:
        addDir(k, ICON, k, 'ds_anime47', url = dulieu[k], p=1)
    endOfDirectory(HANDLE)
def anime47_trangthai():
    dulieu = {
            'Hoàn thành': f'{uanm47}/tim-nang-cao/?status=complete&season=&year=&sort=popular',
            'Đang tiến hành': f'{uanm47}/tim-nang-cao/?status=ongoing&season=&year=&sort=popular'
        }
    for k in dulieu:
        addDir(k, ICON, k, 'ds_anime47', url = dulieu[k], p=1)
    endOfDirectory(HANDLE)
def anime47_xemnhieu():
    current, previous = get_seasons()
    namnay = current[1]
    muatruoc = previous[0]
    nammua = previous[1]
    dulieu = {
        'Ngày': f'{uanm47}/danh-sach/xem-nhieu-trong-ngay.html',
        'Tuần': f'{uanm47}/danh-sach/xem-nhieu-trong-tuan.html',
        'Tháng': f'{uanm47}/danh-sach/xem-nhieu-trong-thang.html',
        'Mùa Này': f'{uanm47}/danh-sach/xem-nhieu-trong-mua.html',
        'Năm Này': f'{uanm47}/danh-sach/xem-nhieu-trong-nam.html',
        'Năm Trước': f'{uanm47}/tim-nang-cao/?status=&season=&year={namnay - 1}&sort=popular',
        'Mùa trước': f'{uanm47}/tim-nang-cao/?status=&season={muatruoc}&year={nammua}&sort=popular',
        'Tất cả': f'{uanm47}/tim-nang-cao/?status=&season=&year=&sort=popular'
        }
    for k in dulieu:
        addDir(k, ICON, k, 'ds_anime47', url = dulieu[k], p=1)
    endOfDirectory(HANDLE)
def anime47_binhluannhieu():
    current, previous = get_seasons()
    muanay = current[0]
    namnay = current[1]
    muatruoc = previous[0]
    nammua = previous[1]
    dulieu = {
        'Mùa Này': f'{uanm47}/tim-nang-cao/?status=&season={muanay}&year={namnay}&sort=comment',
        'Mùa Trước': f'{uanm47}/tim-nang-cao/?status=&season={muatruoc}&year={nammua}&sort=comment',
        'Năm này': f'{uanm47}/tim-nang-cao/?status=&season=&year={namnay}&sort=comment',
        'Năm trước': f'{uanm47}/tim-nang-cao/?status=&season=&year={namnay - 1}&sort=comment',
        'Tất cả': f'{uanm47}/tim-nang-cao/?status=&season=&year=&sort=comment'
        }
    for k in dulieu:
        addDir(k, ICON, k, 'ds_anime47', url = dulieu[k], p=1)
    endOfDirectory(HANDLE)
def anime47_luonglongnhatthe():
    dulieu = {
        'Hành Động + Hài Hước': f'{uanm47}/tim-nang-cao/?status=&genres=24&genres=23&season=&year=&sort=popular',
        'Lãng Mạn + Hành Động': f'{uanm47}/tim-nang-cao/?status=&genres=23&genres=40&season=&year=&sort=popular',
        'Harem + Hài Hước': f'{uanm47}/tim-nang-cao/?status=&genres=36&genres=24&season=&year=&sort=popular',
        'Ecchi + Harem': f'{uanm47}/tim-nang-cao/?status=&genres=36&genres=25&season=&year=&sort=popular',
        'Đời thường - Học Đường': f'{uanm47}/tim-nang-cao/?status=&genres=38&genres=33&season=&year=&sort=popular',
        'Học Đường - Ecchi': f'{uanm47}/tim-nang-cao/?status=&genres=33&genres=25&season=&year=&sort=popular',
        'Romance - Tragedy': f'{uanm47}/tim-nang-cao/?status=&genres=40&genres=64&season=&year=&sort=popular',
        'Kết hợp ngẫu nhiên': f'{uanm47}/tim-nang-cao/?status=&season=&year=&sort=popular'
        }
    for k in dulieu:
        addDir(k, ICON, k, 'ds_anime47', url = dulieu[k], p=1)
    endOfDirectory(HANDLE)
def anime47_nam():
    namnay = localtime().tm_year
    dulieu = {
        f'{namnay - 10}': f'{uanm47}/tim-nang-cao/?status=&season=&year={namnay - 10}&sort=popular',
        f'{namnay - 9}': f'{uanm47}/tim-nang-cao/?status=&season=&year={namnay - 9}&sort=popular',
        f'{namnay - 8}': f'{uanm47}/tim-nang-cao/?status=&season=&year={namnay - 8}&sort=popular',
        f'{namnay - 7}': f'{uanm47}/tim-nang-cao/?status=&season=&year={namnay - 7}&sort=popular',
        f'{namnay - 6}': f'{uanm47}/tim-nang-cao/?status=&season=&year={namnay - 6}&sort=popular',
        f'{namnay - 5}': f'{uanm47}/tim-nang-cao/?status=&season=&year={namnay - 5}&sort=popular',
        f'{namnay - 4}': f'{uanm47}/tim-nang-cao/?status=&season=&year={namnay - 4}&sort=popular',
        f'{namnay - 3}': f'{uanm47}/tim-nang-cao/?status=&season=&year={namnay - 3}&sort=popular',
        f'{namnay - 2}': f'{uanm47}/tim-nang-cao/?status=&season=&year={namnay - 2}&sort=popular',
        f'{namnay - 1}': f'{uanm47}/tim-nang-cao/?status=&season=&year={namnay - 1}&sort=popular',
        namnay: f'{uanm47}/tim-nang-cao/?status=&season=&year={namnay}&sort=popular'
        }
    for k in dulieu:
        addDir(k, ICON, k, 'ds_anime47', url = dulieu[k], p=1)
    endOfDirectory(HANDLE)
def ds_anime47(url, next_page):
    u = f"{url}{next_page}.html" if url.endswith('/') else f"{url}&page={next_page}"
    r = getlink(u, url).text
    npage = f'{next_page + 1}'
    if 'last-film-box' in r:
        parse = fromstring(r)
        root = parse.iterfind('.//ul[@class="last-film-box"]//a')
        for k in root:
            dataanh = domhtml(k, './/div[@class="public-film-item-thumb ratio-content"]', attribute='style')
            img = re.search(r"(http.*?)('|\")", dataanh)[1]
            ten = domhtml(k, './/div[@class="movie-title-1"]')
            link = urljoin(uanm47, k.get('href'))
            addDir(ten, img, ten, 'info_anime47', url = link, img_film=img, namefilm=ten)
    if f'/{npage}.html' in r or f'page={npage}' in r:
        tentrang = f'Trang {npage}'
        addDir(tentrang, nextimg, tentrang, 'ds_anime47', url = url, p=npage)
    endOfDirectory(HANDLE)
def info_anime47(url, img_film, namefilm):
    c = getlink(url,url)
    ref = c.url
    r = c.text
    html = fromstring(r)
    u2 = urljoin(uanm47, re.search(r'episodePlay.*?(\'|")(.*?)\1', r)[2])
    plot = domhtml(html, './/div[@class="news-article"]')
    r2 = getlink(u2 , u2).text
    parse = fromstring(r2)
    root = parse.iterfind('.//div[@class="server"]//a')
    for k in root:
        class_attr = k.get('class', '')
        if 'btn-episode' in class_attr:
            tentap = ''.join(k.itertext()).strip()
            idp = k.get('data-episode-id')
            link = k.get('href')
            fname = f'{namefilm} | {tentap}'
            addDir(fname, img_film, plot, 'play_anime47', idp = idp, ref=ref, is_folder=False)
    rows = list(html.iterfind('.//div[@class="CSSTableGenerator"]//tr'))[1:]
    if rows:
        for row in rows:
            cols = list(row.iterfind(".//td"))
            if len(cols) >= 3:
                ten_phim = domhtml(cols[0], './/a')
                thu_tu = domhtml(cols[1], './/a')
                nam = ''.join(cols[2].itertext()).strip()
                movie_url = domhtml(cols[0], './/a', attribute="href")
                ten = f'{ten_phim} | {thu_tu} | {nam}'
                addDir(ten, img_film, ten, 'info_anime47', url = movie_url, img_film=img_film, namefilm=ten)
    endOfDirectory(HANDLE)
def play_anime47(idp, ref):
    url = urljoin(ref, '/player/player.php')
    payload = {'ID': idp, 'SV':4, 'SV4':4}
    headers = {'User-Agent': UA, 'X-Requested-With': 'XMLHttpRequest'}
    response = requests.post(url, headers=headers, data=payload).text
    thanhhoa = re.search(r'atob\(([\'"])(.*?)\1', response)[2]
    daklak = re.search(r'CryptoJS.AES.decrypt.*?([\'"])(.*?)\1', response)[2]
    decrypted_json = b64decode(thanhhoa).decode('utf-8')
    linkplay = loads(decrypt_cryptojs_aes(decrypted_json, daklak))
    play_item = xbmcgui.ListItem(offscreen=True)
    match = re.search(r'file:\s*([\'"])([^\'"]+)\1[^}]*default:\s*true', response)
    sub = match[2] if match else None
    if sub:
        subfinal = urljoin(ref, sub)
        play_item.setSubtitles([subfinal])
    hdr = f"verifypeer=false&User-Agent={unquote(UA)}&Referer={referer(ref)}"
    linkplay = re.sub(r'\s+', '%20', linkplay.strip(), flags=re.UNICODE)
    play_item.setProperty('inputstream', 'inputstream.adaptive')
    play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
    play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
    play_item.setPath(linkplay)
    setResolvedUrl(HANDLE, True, listitem=play_item)
def search():
    query = xbmcgui.Dialog().input(u'Tìm: tên phim ...', type=xbmcgui.INPUT_ALPHANUM)
    if query:
        search_history_save(query)
        timkiem(query)
    else:
        find()
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action_map = {
        'anime47_theloai': anime47_theloai,
        'anime47_trangthai': anime47_trangthai,
        'anime47_xemnhieu': anime47_xemnhieu,
        'anime47_binhluannhieu': anime47_binhluannhieu,
        'anime47_luonglongnhatthe': anime47_luonglongnhatthe,
        'anime47_nam': anime47_nam,
        'ds_anime47': partial(ds_anime47, params.get('url'), int(params.get('p', 1))),
        'info_anime47': partial(info_anime47, params.get('url'), params.get('img_film'), params.get('namefilm')),
        'search': search,
        'timkiem': find,
        'timanime47': partial(timkiem, params.get('key')),
        'play_anime47': partial(play_anime47, params.get('idp'), params.get('ref')),
    }
    action_map.get(params.get('mode'), main)()
try:
    router(sys.argv[2][1:])
except:
    pass