from urllib.parse import parse_qsl
from xbmcplugin import addDirectoryItem, endOfDirectory, setContent
from functools import partial
from xbmcaddon import Addon
from xbmcvfs import translatePath
from xbmcgui import ListItem
from pickle import load, dump
from xbmc import executebuiltin
import sys, os
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
ICON = Addon().getAddonInfo('icon')
addon_data_dir = os.path.join(translatePath('special://userdata/addon_data'), 'plugin.video.daxem')
def create_list_item(title, url=None, context_menu=None):
    list_item = xbmcgui.ListItem(label=f'{title}')
    list_item.setArt({'icon': ICON, 'thumb': ICON, 'poster': ICON, 'fanart': ICON})
    list_item.setInfo('video', infoLabels={'title': f'{title}', 'plot': f'{title}'})
    if context_menu:
        list_item.addContextMenuItems(context_menu)
    list_item.setProperty('IsPlayable', 'true')
    return list_item
def get_file_path(filename):
    return os.path.join(addon_data_dir, filename)
def read_file(filename):
    path = get_file_path(filename)
    if not os.path.exists(path):
        return None
    try:
        with open(path, 'rb') as f:
            return load(f)
    except:
        return None
def write_file(filename, data):
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)
    path = get_file_path(filename)
    try:
        with open(path, 'wb') as f:
            dump(data, f)
    except:
        pass
    return path
def get_last_watch():
    return read_file('daxem.pkl') or []
def remove_search_history(search_key):
    content = read_file('daxem.pkl') or []
    if search_key in content:
        content.pop(search_key)
        write_file('daxem.pkl', content)
    executebuiltin('Container.Refresh()')
def search_history_clear():
    write_file('daxem.pkl', [])
    executebuiltin('Container.Refresh()')
def main():
    data= get_last_watch()
    if data:
        setContent(HANDLE, 'videos')
        for key, value in data.items():
            list_item = create_list_item(
                title=key,
                context_menu=[('Xóa', f'RunPlugin({addon_url}?mode=remove&key={key})')]
            )
            addDirectoryItem(HANDLE, value, list_item, False)
        list_item_all = create_list_item(
            title='Xóa tất cả lịch sử',
            url=f'{addon_url}?mode=removeall'
        )
        addDirectoryItem(HANDLE, f'{addon_url}?mode=removeall', list_item_all, False)
    endOfDirectory(HANDLE)
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action_map = {
        'remove': partial(remove_search_history, params.get('key')),
        'removeall': search_history_clear,
    }
    action_map.get(params.get('mode'), main)()
try:
    router(sys.argv[2][1:])
except:
    pass