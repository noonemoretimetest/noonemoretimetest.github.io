from urllib.parse import urlencode, parse_qsl, quote_plus, unquote
from functools import partial
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from concurrent.futures import ThreadPoolExecutor
from xbmcaddon import Addon
from xbmcvfs import translatePath
from html import unescape
from pickle import load, dump
from requests import Session
from xbmcgui import ListItem, Dialog, INPUT_ALPHANUM
from sys import argv
import re, os
addon_url = argv[0]
HANDLE = int(argv[1])
addon_id = Addon().getAddonInfo('id')
ICON = Addon().getAddonInfo('icon')
PATH = Addon().getAddonInfo('path')
RESOURCES = PATH + '/media/'
searchimg = RESOURCES +'search.png'
nextimg = RESOURCES + 'next.png'
opimg = RESOURCES + 'op.png'
kkimg = RESOURCES + 'kk.png'
rfimg = RESOURCES + 'rf.png'
UA = 'Mozilla/5.0 (Linux; Android 15; Pixel 9 Pro Build/AP4A.261212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/605.1.15 EdgA/140.0.0.0'
addon_data_dir = os.path.join(translatePath('special://userdata/addon_data'), addon_id)
o1 = 'https://ophim1.com'
uop = f'{o1}/v1/api'
op = 'https://ophim.live'
ukk = 'https://phimapi.com'
kk = 'https://kkphim.com'
rf = 'https://api.rophim.me/v1/'
kmapi = 'https://pm-api.hth4nh.eu.org'
def addDir(title, img, plot, mode, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = ListItem(label=f'{title}')
    list_item.setArt({'icon': img, 'thumb': img, 'poster': img, 'fanart': img})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(f'{title}')
    info_tag.setPlot(f'{plot}')
    setContent(HANDLE, 'videos')
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref):
    with Session() as s:
        s.headers.update({'user-agent': UA,'referer': ref.encode('utf-8')})
        try:
            r = s.get(url, timeout=20)
        except:
            r = s.get(url, timeout=20, verify=False)
    r.encoding = 'utf-8'
    return r
def get_file_path(filename):
    return os.path.join(addon_data_dir, filename)
def read_file(filename):
    path = get_file_path(filename)
    if not os.path.exists(path):
        return None
    try:
        with open(path, 'rb') as f:
            return load(f)
    except:
        return None
def write_file(filename, data):
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)
    path = get_file_path(filename)
    try:
        with open(path, 'wb') as f:
            dump(data, f)
    except:
        pass
    return path
def search_history_save(search_key):
    if not search_key:
        return
    history = read_file('historys.pkl') or []
    if search_key in history:
        history.remove(search_key)
    elif len(history) >= 20:
        history.pop()
    history.insert(0, search_key)
    write_file('historys.pkl', history)
def search_history_get():
    return read_file('historys.pkl') or []
def safe_join(value):
    if isinstance(value, list):
        return ','.join(value)
    return value
def convert_image_url(path):
    filename = path.split('/')[-1]
    return f"https://static.nutscdn.com/vimg/300-0/{filename}"
def find():
    addDir('Tìm phim', searchimg, 'Tìm phim', 'search')
    b = search_history_get()
    if b:
        for m in b:
            addDir(m, ICON, m, 'tim_apii', key=m, p=1)
    endOfDirectory(HANDLE)
def get_info_ophim(x):
    r = getlink(f'{uop}/phim/{x}','https://ophim1.com/')
    try:
        kq = r.json()['data']
        try:
            img = kq['seoOnPage']['seoSchema']['image']
        except:
            img = opimg
        try:
            ten = kq['item']['name']
        except:
            pass
        try:
            mota = unescape(re.sub('<.*?>', '', kq['item']['content']))
        except:
            mota = ten
        return (ten, img, mota)
    except:
        return None
def get_info_kkphim(x):
    r = getlink(f'{ukk}/phim/{x}',ukk)
    try:
        kq = r.json()['movie']
        try:
            img = kq['poster_url']
        except:
            img = kkimg
        try:
            ten = kq['name']
        except:
            pass
        try:
            mota = unescape(kq['content'])
        except:
            mota = ten
        return (ten, img, mota)
    except:
        return None
def op_process_url(url):
    try:
        data = get_info_ophim(url)
        return url, data
    except:
        return url, None
def kk_process_url(url):
    try:
        data = get_info_kkphim(url)
        return url, data
    except:
        return url, None
def get_op(search_query, next_page):
    r = getlink(f'{uop}/tim-kiem?keyword={search_query}&page={next_page}', uop)
    return ((k['name'], k['thumb_url'], k['slug'], r.json()['data']['APP_DOMAIN_CDN_IMAGE']) for k in r.json()['data']['items'])
def get_kk(search_query, next_page):
    r = getlink(f'{ukk}/v1/api/tim-kiem?keyword={search_query}&page={next_page}', ukk)
    return ((k['name'], k['poster_url'], k['slug'], r.json()['data']['APP_DOMAIN_CDN_IMAGE']) for k in r.json()['data']['items'])
def timkiem(query, next_page):
    sr = quote_plus(query)
    processed_ids = set()
    with ThreadPoolExecutor(2) as ex:
        f1 = ex.submit(get_op, sr, next_page)
        f2 = ex.submit(get_kk, sr, next_page)
    try:
        for k in f1.result():
            if k[2] not in processed_ids:
                addDir(k[0], f'{k[3]}/uploads/movies/{k[1]}', k[0], 'id_film', id=k[2])
                processed_ids.add(k[2])
    except:
        pass
    try:
        for l in f2.result():
            if l[2] not in processed_ids:
                addDir(l[0], f'{l[3]}/{l[1]}', l[0], 'id_film', id=l[2])
                processed_ids.add(l[2])
    except:
        pass
    tiep = f'{next_page + 1}'
    addDir(f'Trang {tiep}', nextimg, f'Trang {tiep}', 'tim_apii', key=query, p=tiep)
    endOfDirectory(HANDLE)
def op_phanloai(phanloai, trang):
    u = f'{o1}/{phanloai}'
    resp = getlink(u, u)
    ri = resp.json()
    for k in ri:
        ten = k['name']
        addDir(ten, ICON, ten, 'ds_op', url = f"{uop}/{phanloai}/{k['slug']}", p=trang)
    endOfDirectory(HANDLE)
def kk_phanloai(phanloai, trang):
    u = f'{ukk}/{phanloai}'
    resp = getlink(u, u)
    ri = resp.json()
    for k in ri:
        ten = k['name']
        addDir(ten, ICON, ten, 'ds_kk', url = f"{ukk}/v1/api/{phanloai}/{k['slug']}?limit=30", p=trang)
    endOfDirectory(HANDLE)
def ds_op(match, next_page):
    n = f'{match}&page={next_page}' if '?' in match else f'{match}?page={next_page}'
    resp = getlink(n, n)
    ri = resp.json()['data']['items']
    urls = [k['slug'] for k in ri]
    length = len(urls)
    if length>0:
        with ThreadPoolExecutor(length) as ex:
            results = ex.map(op_process_url, urls)
        for (l, data) in results:
            if data is not None:
                addDir(data[0], data[1], data[2], 'id_film', id = l)
        tiep = f'{next_page + 1}'
        addDir(f'Trang {tiep}', nextimg, f'Trang {tiep}', 'ds_op', url = match, p=tiep)
    endOfDirectory(HANDLE)
def ds_kk(match, next_page):
    n = f'{match}&page={next_page}' if '?' in match else f'{match}?page={next_page}'
    resp = getlink(n, n)
    ri = resp.json()['data']['items'] if (resp is not None) and ('"data"' in resp.text) else resp.json()['items']
    urls = [k['slug'] for k in ri]
    length = len(urls)
    if length>0:
        with ThreadPoolExecutor(length) as ex:
            results = ex.map(kk_process_url, urls)
        for (l, data) in results:
            if data is not None:
                addDir(data[0], data[1], data[2], 'id_film', id=l)
        if (next_page < resp.json().get('data', {}).get('params', {}).get('pagination', {}).get('totalItemsPerPage', float('inf')) or
            next_page < resp.json().get('items', {}).get('pagination', {}).get('totalItemsPerPage', float('inf'))):
            tiep = f'{next_page + 1}'
            addDir(f'Trang {tiep}', nextimg, f'Trang {tiep}', 'ds_kk', url = match, p=tiep)
    endOfDirectory(HANDLE)
def id_km(sv, idk):
    try:
        t = f'{kmapi}/{sv}/detail/{idk}'
        resp = getlink(t, t)
        kq = resp.json()['sources']
        pname = idk.replace('-', ' ').title()
        return (
            (f"{k['name']} {v['name']}", p['name'], v['url'], pname)
            for k in kq
            for m in k['contents']
            for p in m['streams']
            for v in p['stream_links']
            if v['url']
        )
    except:
        return False
def play_vn(link):
    enlink = re.sub(r'\s+', '%20', link.strip(), flags=re.UNICODE)
    play_item = ListItem(offscreen=True, path=enlink)
    hdr = f'verifypeer=false&User-Agent={unquote(UA)}'
    play_item.setProperty('inputstream', 'inputstream.adaptive')
    play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
    play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
    setResolvedUrl(HANDLE, True, listitem=play_item)
def main():
    addDir('Tìm phim', searchimg, 'Tìm phim', 'timkiem')
    addDir('Nổi bật', rfimg, 'Nổi bật', 'rf_hot')
    addDir('Phim mới', rfimg, 'Phim mới', 'rophim_index', url = f'{rf}movie/filterV2?countries=&genres=&years=&type=&status=&exclude_status=Upcoming&versions=&rating=&networks=&productions=&sort=release_date&keyword=', p = 1)
    addDir('Phim nóng', rfimg, 'Phim nóng', 'rf_nong')
    addDir('Ngẫu nhiên', rfimg, 'Ngẫu nhiên', 'rf_ngaunhien')
    addDir('Phim lẻ', rfimg, 'Phim lẻ', 'rophim_index', url = f'{rf}movie/filterV2?countries=&genres=&years=&type=1&status=&exclude_status=Upcoming&versions=&rating=&networks=&productions=&sort=release_date&keyword=', p = 1)
    addDir('Phim bộ', rfimg, 'Phim bộ', 'rophim_index', url = f'{rf}movie/filterV2?countries=&genres=&years=&type=2&status=&exclude_status=Upcoming&versions=&rating=&networks=&productions=&sort=release_date&keyword=', p = 1)
    addDir('Đỉnh nóc', rfimg, 'Đỉnh nóc', 'rf_dinhnoc')
    u = f'{rf}collection/list?page=1&limit=100'
    response = getlink(u, rf).json()['result']['collections']
    for k in response:
        name = k['name']
        if 'filter' not in k or k['type'] == 1:
            idp = k['_id']
            addDir(name, rfimg, name, 'rophim_index2', idp = idp)
        else:
            filterx = k['filter']
            VALID_SORT_OPTIONS = {'release_date', 'updated_at', 'imdb_rating', 'total_views'}
            params = {
                'countries': safe_join(filterx.get('country_code', '')),
                'genres': safe_join(filterx.get('genre_ids', '')),
                'years': safe_join(filterx.get('years', '')),
                'type': safe_join(filterx.get('type', '')),
                'status': safe_join(filterx.get('status', '')),
                'exclude_status': safe_join(filterx.get('exclude_status', '')),
                'versions': safe_join(filterx.get('versions', '')),
                'rating': safe_join(filterx.get('rating', '')),
                'networks': safe_join(filterx.get('networks', '')),
                'productions': safe_join(filterx.get('productions', '')),
                'sort': filterx.get('sort_by', '') if filterx.get('sort_by', '') in VALID_SORT_OPTIONS else 'release_date',
                'keyword': ''
            }
            url = f"{rf}movie/filterV2?" + '&'.join(f"{k}={v.replace(' ', '%20')}" for k, v in params.items())
            addDir(name, rfimg, name, 'rophim_index', url = url, p = 1)
    addDir('OPHIM', opimg, 'OPHIM', 'op_index')
    addDir('KKPHIM', kkimg, 'KKPHIM', 'kk_index')
    endOfDirectory(HANDLE)
def rf_hot():
    u = f'{rf}movie/hot'
    r = getlink(u, rf).json()['result']
    for k in r:
        name = k['title']
        info = k['overview']
        img = convert_image_url(k['images']['posters'][-1]['path'])
        slug = k['slug']
        addDir(name, img, info, 'id_film', id=slug)
    endOfDirectory(HANDLE)
def rf_nong():
    u = f'{rf}movie/seoData'
    r = getlink(u, rf).json()['result']['hotMovies']
    for k in r:
        name = k['title']
        info = k['overview']
        img = convert_image_url(k['images']['posters'][-1]['path'])
        slug = k['slug']
        addDir(name, img, info, 'id_film', id=slug)
    endOfDirectory(HANDLE)
def rf_ngaunhien():
    u = f'{rf}movie/seoData'
    r = getlink(u, rf).json()['result']['randomMovies']
    for k in r:
        name = k['title']
        info = k['overview']
        img = convert_image_url(k['images']['posters'][-1]['path'])
        slug = k['slug']
        addDir(name, img, info, 'id_film', id=slug)
    endOfDirectory(HANDLE)
def rf_dinhnoc():
    u = f'{rf}collection/movies/HqM5a6'
    r = getlink(u, rf).json()['result']
    for k in r:
        name = k['title']
        info = k['overview']
        img = convert_image_url(k['images']['posters'][-1]['path'])
        slug = k['slug']
        addDir(name, img, info, 'id_film', id=slug)
    endOfDirectory(HANDLE)
def rophim_index(url, p):
    u = f'{url}&page={p}'
    r = getlink(u, rf).json()['result']
    page_count = r['page_count']
    for k in r['items']:
        name = k['title']
        info = k['overview']
        img = convert_image_url(k['images']['posters'][-1]['path'])
        slug = k['slug']
        addDir(name, img, info, 'id_film', id=slug)
    if page_count > 1:
        tiep = f'{p + 1}'
        addDir(f'Trang {tiep}', nextimg, f'Trang {tiep}', 'rophim_index', url = url, p = tiep)
    endOfDirectory(HANDLE)
def rophim_index2(idp):
    u = f'{rf}collection/list?page=1&limit=100'
    r = getlink(u, rf).json()['result']['collections']
    for k in r:
        if k['_id'] == idp:
            for m in k['movies']:
                name = m['title']
                info = m['overview']
                img = convert_image_url(m['images']['posters'][-1]['path'])
                slug = m['slug']
                addDir(name, img, info, 'id_film', id=slug)
    endOfDirectory(HANDLE)
def op_index():
    T = {'Thể loại': 'op_tl',
    'Quốc gia': 'op_qg'}
    dulieu = {
    'Phim mới': f'{uop}/danh-sach/phim-moi-cap-nhat',
    'Phim bộ': f'{uop}/danh-sach/phim-bo',
    'Phim bộ hoàn thành': f'{uop}/danh-sach/phim-bo-hoan-thanh',
    'Phim lẻ': f'{uop}/danh-sach/phim-le',
    'TV shows': f'{uop}/danh-sach/tv-shows',
    'Hoạt hình': f'{uop}/danh-sach/hoat-hinh',
    'Phim thuyết minh': f'{uop}/danh-sach/phim-thuyet-minh',
    'Phim lồng tiếng': f'{uop}/danh-sach/phim-long-tieng',
    'Phim phụ đề': f'{uop}/danh-sach/phim-vietsub',
    'Phim phụ đề độc quyền': f'{uop}/danh-sach/subteam'
    }
    for b in T:
        addDir(b, opimg, b, T[b])
    for k in dulieu:
        addDir(k, opimg, k, 'ds_op', url = dulieu[k], p=1)
    endOfDirectory(HANDLE)
def kk_index():
    T = {'Thể loại': 'kk_tl',
    'Quốc gia': 'kk_qg'}
    dulieu = {
    'Phim mới': f'{ukk}/danh-sach/phim-moi-cap-nhat-v2?limit=30',
    'Phim lẻ': f'{ukk}/v1/api/danh-sach/phim-le?limit=30',
    'Phim bộ': f'{ukk}/v1/api/danh-sach/phim-bo?limit=30',
    'Hoạt hình': f'{ukk}/v1/api/danh-sach/hoat-hinh?limit=30',
    'TV Shows': f'{ukk}/v1/api/danh-sach/tv-shows?limit=30'
    }
    for b in T:
        addDir(b, kkimg, b, T[b])
    for k in dulieu:
        addDir(k, kkimg, k, 'ds_kk', url = dulieu[k], p=1)
    endOfDirectory(HANDLE)
def id_film(idk):
    with ThreadPoolExecutor(2) as ex:
        futures = {
            'OP': ex.submit(id_km, 'ophim', idk),
            'KK': ex.submit(id_km, 'kk', idk)
        }
    for label, future in futures.items():
        result = future.result()
        if result:
            for item in result:
                ep = f'Tập {item[1]}' if not item[1].startswith('Tập') else item[1]
                name = f"{item[3]} | {label} {item[0]} | {ep}"
                addDir(name, ICON, name, 'play_vn', url=item[2], is_folder=False)
    endOfDirectory(HANDLE)
def search():
    query = Dialog().input(u'Tìm: tên phim ...', type=INPUT_ALPHANUM)
    if query:
        search_history_save(query)
        timkiem(query, 1)
    else:
        find()
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action_map = {
        'op_index': op_index,
        'kk_index': kk_index,
        'rf_hot': rf_hot,
        'rf_nong': rf_nong,
        'rf_ngaunhien': rf_ngaunhien,
        'rf_dinhnoc': rf_dinhnoc,
        'op_tl': partial(op_phanloai, 'the-loai', 1),
        'op_qg': partial(op_phanloai, 'quoc-gia', 1),
        'kk_tl': partial(kk_phanloai, 'the-loai', 1),
        'kk_qg': partial(kk_phanloai, 'quoc-gia', 1),
        'ds_op': partial(ds_op, params.get('url'), int(params.get('p', 0))),
        'ds_kk': partial(ds_kk, params.get('url'), int(params.get('p', 0))),
        'rophim_index': partial(rophim_index, params.get('url'), int(params.get('p', 0))),
        'id_film': partial(id_film, params.get('id')),
        'rophim_index2': partial(rophim_index2, params.get('idp')),
        'search': search,
        'timkiem': find,
        'tim_apii': partial(timkiem, params.get('key'), int(params.get('p', 0))),
        'play_vn': partial(play_vn, params.get('url')),
    }
    action_map.get(params.get('mode'), main)()
try:
    router(argv[2][1:])
except:
    pass