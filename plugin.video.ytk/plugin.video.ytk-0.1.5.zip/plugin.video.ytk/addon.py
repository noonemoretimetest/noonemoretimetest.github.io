from urllib.parse import urlencode, parse_qsl
from functools import partial
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from pickle import load, dump
from xbmcvfs import translatePath
from sys import argv
from requests import Session
from xbmcgui import ListItem, Dialog, INPUT_ALPHANUM
import os
addon_url = argv[0]
HANDLE = int(argv[1])
ICON = Addon().getAddonInfo('icon')
PATH = Addon().getAddonInfo('path')
addon_id = Addon().getAddonInfo('id')
RESOURCES = PATH + '/media/'
searchimg = RESOURCES +'search.png'
API_KEY = 'AIzaSyDMGvnC4vv_06oMy2C1Zd5MJyqaqz3aY5M'
addon_data_dir = os.path.join(translatePath('special://userdata/addon_data'), addon_id)
def addDir(title, img, mode, plot, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = ListItem(label=f'{title}')
    list_item.setArt({'icon': img, 'thumb': img, 'poster': img})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(f'{title}')
    info_tag.setPlot(f'{plot}')
    if not is_folder:
        setContent(HANDLE, 'episodes')
        list_item.setProperty('IsPlayable', 'true')
    else:
        setContent(HANDLE, 'tvshows')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def get_file_path(filename):
    return os.path.join(addon_data_dir, filename)
def read_file(filename):
    path = get_file_path(filename)
    if not os.path.exists(path):
        return None
    try:
        with open(path, 'rb') as f:
            return load(f)
    except:
        return None
def write_file(filename, data):
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)
    path = get_file_path(filename)
    try:
        with open(path, 'wb') as f:
            dump(data, f)
    except:
        pass
    return path
def search_history_save(search_key):
    if not search_key:
        return
    history = read_file('historys.pkl') or []
    if search_key in history:
        history.remove(search_key)
    elif len(history) >= 20:
        history.pop()
    history.insert(0, search_key)
    write_file('historys.pkl', history)
def search_history_get():
    return read_file('historys.pkl') or []
def find():
    addDir('Tìm kiếm', searchimg, 'search', 'Tìm kiếm', is_folder=True)
    b = search_history_get()
    if b:
        for m in b:
            addDir(m, ICON, 'tim_yt', m, key = m, is_folder=True)
    endOfDirectory(HANDLE)
def timkiem(query):
    url = 'https://www.googleapis.com/youtube/v3/search'
    params = {
        'part': 'snippet',
        'q': query,
        'type': 'video',
        'regionCode': 'VN',
        'maxResults': 50,
        'key': API_KEY
    }
    with Session() as s:
        try:
            data = s.get(url, params=params).json()
        except:
            data = s.get(url, params=params, verify=False).json()
    for item in data['items']:
        tenm = item['snippet']['title']
        idvd = item['id']['videoId']
        img = f'https://i.ytimg.com/vi/{idvd}/sddefault.jpg'
        description = item['snippet']['description']
        channel_title = item['snippet']['channelTitle']
        plot = f'[COLOR yellow]{channel_title}[/COLOR] {description}'
        addDir(tenm, img, 'play_yt', plot, id=idvd, is_folder=False)
    endOfDirectory(HANDLE)
def main():
    addDir('Tìm kiếm', searchimg, 'timkiem', 'Tìm kiếm', is_folder=True)
    addDir('Trending', ICON, 'trending', 'Trending', is_folder=True)
    endOfDirectory(HANDLE)
def search():
    query = Dialog().input(u'Tìm: tên video ...', type=INPUT_ALPHANUM)
    if query:
        search_history_save(query)
        timkiem(query)
    else:
        find()
def trending():
    url = 'https://www.googleapis.com/youtube/v3/videos'
    params = {
        'part': 'snippet,statistics',
        'chart': 'mostPopular',
        'regionCode': 'VN',
        'maxResults': 50,
        'key': API_KEY
    }
    with Session() as s:
        try:
            data = s.get(url, params=params).json()
        except:
            data = s.get(url, params=params, verify=False).json()
    for item in data['items']:
        tenm = item['snippet']['title']
        idvd = item['id']
        description = item['snippet']['description']
        channel_title = item['snippet']['channelTitle']
        plot = f'[COLOR yellow]{channel_title}[/COLOR] {description}'
        img = f'https://i.ytimg.com/vi/{idvd}/sddefault.jpg'
        addDir(tenm, img, 'play_yt', plot, id=idvd, is_folder=False)
    endOfDirectory(HANDLE)
def play_yt(idp):
    play_item = ListItem(offscreen=True, path=f'plugin://plugin.video.mytube/?action=play&videoId={idp}')
    setResolvedUrl(HANDLE, True, listitem=play_item)
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action_map = {
        'search': search,
        'timkiem': find,
        'tim_yt': partial(timkiem, params.get('key')),
        'trending': trending,
        'play_yt': partial(play_yt, params.get('id'))
    }
    action_map.get(params.get('mode'), main)()
try:
    router(argv[2][1:])
except:
    pass