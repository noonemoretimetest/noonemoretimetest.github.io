from urllib.parse import urlencode, parse_qsl, unquote, quote_plus, urlparse, urljoin
from functools import partial
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from pickle import load, dump
from xbmcvfs import translatePath
from htmlement import fromstring
from pathlib import Path
from time import localtime
from sys import argv
from json import loads
from requests import Session
from xbmcgui import ListItem, Dialog, INPUT_ALPHANUM
from threading import Thread
from bottle import Bottle, response
from random import randint
from socket import socket, AF_INET, SOCK_STREAM
from resolveurl import resolve
import re, os
addon_url = argv[0]
HANDLE = int(argv[1])
addon_id = Addon().getAddonInfo('id')
ICON = Addon().getAddonInfo('icon')
PATH = Addon().getAddonInfo('path')
RESOURCES = PATH + '/media/'
searchimg = RESOURCES +'search.png'
nextimg = RESOURCES + 'next.png'
apiq = 'https://api-zophim.blogspot.com/search?q='
UA = 'Mozilla/5.0 (SMART-TV; LINUX; Tizen 9.0) AppleWebKit/537.36 (KHTML, like Gecko) 120.0.6099.5/9.0 TV Safari/537.36'
addon_data_dir = os.path.join(translatePath('special://userdata/addon_data'), addon_id)
app = Bottle()
def addDir(title=None, img=None, plot=None, mode=None, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = ListItem(label=f'{title}')
    list_item.setArt({'icon': img, 'thumb': img, 'poster': img, 'fanart': img})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(f'{title}')
    info_tag.setPlot(f'{plot}')
    setContent(HANDLE, 'videos')
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref):
    with Session() as s:
        s.headers.update({'user-agent': UA,'referer': ref.encode('utf-8')})
        try:
            r = s.get(url, timeout=20)
        except:
            r = s.get(url, timeout=20, verify=False)
    r.encoding = 'utf-8'
    return r
def getrow(cell):
    return (cell or {}).get('v') or ''
def domhtml(root, xpath, attribute=None, default=None):
    element = root.find(xpath)
    return default if element is None else element.get(attribute, '\n'.join(element.itertext()).strip())
def referer(url):
    parsed_url = urlparse(url.strip())
    return f'{parsed_url.scheme}://{parsed_url.netloc}/'
def get_file_path(filename):
    return os.path.join(addon_data_dir, filename)
def limit_files_in_directory(directory):
    files = sorted(Path(directory).glob('*'), key=os.path.getmtime)
    while len(files) > 5:
        oldest_file = files.pop(0)
        try:
            oldest_file.unlink()
        except Exception as e:
            pass
def get_random_free_port(start=10000, end=65535):
    while True:
        port = randint(start, end)
        with socket(AF_INET, SOCK_STREAM) as s:
            if s.connect_ex(('127.0.0.1', port)) != 0:
                return port
@app.route('/<filename>')
def serve_m3u8(filename):
    path = os.path.join(addon_data_dir, filename)
    if not os.path.exists(path):
        response.status = 404
        return 'Not found'
    response.content_type = 'application/vnd.apple.mpegurl'
    with open(path, 'r', encoding='utf-8') as f:
        return f.read()
def start_server():
    port = get_random_free_port()
    Thread(target=lambda: app.run(host='127.0.0.1', port=port), daemon=True).start()
    return port
def process_m3u8(url):
    lines = getlink(url, url).text.splitlines()
    cleaned_lines = []
    for line in lines:
        if not line.startswith("#"):
            line = urljoin(url, line)
        cleaned_lines.append(line)
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)
    parsed_url = urlparse(url.strip())
    path_parts = [p for p in parsed_url.path.strip('/').split('/') if p]
    if not path_parts:
        path_parts = ['playlist']
    filename_root, _ = os.path.splitext(path_parts[-1])
    path_parts[-1] = f'{filename_root}.m3u8'
    name = '_'.join(path_parts)
    path = os.path.join(addon_data_dir, name)
    with open(path, 'w+', encoding='utf-8') as f:
        f.write('\n'.join(cleaned_lines))
    limit_files_in_directory(addon_data_dir)
    return name
def read_file(filename):
    path = get_file_path(filename)
    if not os.path.exists(path):
        return None
    try:
        with open(path, 'rb') as f:
            return load(f)
    except:
        return None
def write_file(filename, data):
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)
    path = get_file_path(filename)
    try:
        with open(path, 'wb') as f:
            dump(data, f)
    except:
        pass
    return path
def search_history_save(search_key):
    if not search_key:
        return
    history = read_file('historys.pkl') or []
    if search_key in history:
        history.remove(search_key)
    elif len(history) >= 20:
        history.pop()
    history.insert(0, search_key)
    write_file('historys.pkl', history)
def search_history_get():
    return read_file('historys.pkl') or []
def filmnew():
    url = 'https://docs.google.com/spreadsheets/d/16lOAdRoReQ3JbVIKf-_gXL6JQa7YJ_JkwRo28IT6XS4/gviz/tq?gid=0&headers=1'
    resp = getlink(url, url)
    noi = resp.text.split("setResponse(",1)[1].rsplit(");",1)[0]
    m = loads(noi)
    rows = m['table']['rows']
    for r in reversed(rows):
        if (c := r['c']):
            slug= getrow(c[2])
            ten_phim= getrow(c[3])
            thumb= getrow(c[5])
            trang_thai= getrow(c[11])
            noi_dung= getrow(c[13])
            addDir(ten_phim, thumb, noi_dung, 'pm_animeviesub', slug = slug, trang_thai=trang_thai, ten=ten_phim, noi_dung=noi_dung, thumb=thumb)
    endOfDirectory(HANDLE)
def pm_animeviesub(slug, trang_thai, ten, noi_dung, thumb):
    numbers = re.findall(r'\d+', trang_thai)
    if not numbers:
        namef = f'{ten} | Tập Full'
        cdn = f'https://anicdn.top/{slug}/Full'
        cdn_animeviesub(cdn, thumb, namef, noi_dung)
    else:
        max_eps = max(int(n) for n in numbers)
        for i in range(1, max_eps + 1):
            namef = f'{ten} | Tập {i}'
            cdn = f'https://anicdn.top/{slug}/{i}'
            addDir(namef, thumb, noi_dung, 'cdn_animeviesub', url = cdn, img_film=thumb, namefilm=namef, noi_dung=noi_dung)
        endOfDirectory(HANDLE)
def cdn_animeviesub(url, img_film, namefilm, noi_dung):
    r = getlink(url,url).text 
    parse = fromstring(r)
    root = parse.iterfind('.//div[@class="tabs"]//div[@id]')
    for k in root:
        s = k.get('onclick')
        sv = re.search(r"(['\"])(.*?)(\1)", s)[2]
        tensv = ' '.join(k.itertext()).strip()
        fname = f'{namefilm} | {tensv}'
        addDir(fname, img_film, noi_dung, 'svplay_animeviesub', url=sv, name=fname, img_film=img_film, mota=noi_dung)
    endOfDirectory(HANDLE)
def main():
    addDir('Tìm kiếm', searchimg, 'Tìm kiếm', 'timkiem')
    addDir('Phim mới', ICON, 'Phim mới', 'filmnew')
    dulieu = {
        'Phim hot': 'https://api-zophim.blogspot.com/',
        'Phim bộ': 'https://api-zophim.blogspot.com/search/label/Series',
        'Phim lẻ': 'https://api-zophim.blogspot.com/search/label/Movie',
        'Thuyết Minh': 'https://api-zophim.blogspot.com/search?q=TM',
        'Lồng Tiếng': 'https://api-zophim.blogspot.com/search?q=LT',
        'Việt Sub': 'https://api-zophim.blogspot.com/search?q=VS'
        }
    T = {'Thể loại': 'animeviesub_theloai',
        'Quốc gia': 'animeviesub_quocgia',
        'Năm': 'animeviesub_nam'
        }
    for k in dulieu:
        addDir(k, ICON, k, 'ds_animeviesub', url = dulieu[k])
    for b in T:
        addDir(b, ICON, b, T[b])
    endOfDirectory(HANDLE)
def find():
    addDir('Tìm kiếm', searchimg, 'Tìm kiếm', 'search')
    b = search_history_get()
    if b:
        for m in b:
            addDir(m, searchimg, m, 'timanimeviesub', key = m)
    endOfDirectory(HANDLE)
def timkiem(query):
    sr = quote_plus(query)
    url = f'{apiq}{sr}'
    ds_animeviesub(url)
def animeviesub_theloai():
    dulieu = ['Tu Tiên', 'Học Đường', 'Xuyên Không', 'Bí Ẩn', 'Trinh Thám', 'Đời Thường', 'Thể Thao', 'Hình Sự', 'Harem', 'Hiện Đại', 'Âm Nhạc', 'Dị Giới', 'Khoa Học', 'Luyện Cấp', 'Chuyển Sinh', 'Phiêu Lưu', 'Hài Hước', 'Võ Thuật', 'Viễn Tưởng', 'Hành Động', 'Kinh Dị', 'Cổ Trang', 'Tình Yêu', '18 Plus']
    for k in dulieu:
        addDir(k, ICON, k, 'ds_animeviesub', url = f'{apiq}{quote_plus(k)}')
    endOfDirectory(HANDLE)
def animeviesub_quocgia():
    dulieu = ['Trung Quốc', 'Nhật Bản', 'Âu Mỹ']
    for k in dulieu:
        addDir(k, ICON, k, 'ds_animeviesub', url = f'{apiq}{quote_plus(k)}')
    endOfDirectory(HANDLE)
def animeviesub_nam():
    namnay = localtime().tm_year
    dulieu = {
        f'{namnay - 9}': f'{apiq}{namnay - 9}',
        f'{namnay - 8}': f'{apiq}{namnay - 8}',
        f'{namnay - 7}': f'{apiq}{namnay - 7}',
        f'{namnay - 6}': f'{apiq}{namnay - 6}',
        f'{namnay - 5}': f'{apiq}{namnay - 5}',
        f'{namnay - 4}': f'{apiq}{namnay - 4}',
        f'{namnay - 3}': f'{apiq}{namnay - 3}',
        f'{namnay - 2}': f'{apiq}{namnay - 2}',
        f'{namnay - 1}': f'{apiq}{namnay - 1}',
        namnay: f'{apiq}{namnay}&sort=popular'
        }
    for k in dulieu:
        addDir(k, ICON, k, 'ds_animeviesub', url = dulieu[k])
    endOfDirectory(HANDLE)
def ds_animeviesub(u):
    r = getlink(u,u).text
    parse = fromstring(r)
    root = parse.iterfind('.//table[@style]/tr[@onclick]')
    for k in root:
        img = domhtml(k, './/img', attribute='src')
        ten = domhtml(k, './/font')
        try:
            m = re.search(r'(\'|")(.*?)\1', k.get('onclick'))
            link = urljoin(u, m[2])
            addDir(ten, img, ten, 'info_animeviesub', url = link, img_film=img, namefilm=ten)
        except:
            pass
    if 'blog-pager-older-link' in r:
        p = domhtml(parse, './/a[@class="blog-pager-older-link"]', attribute='href')
        addDir('Trang tiếp', nextimg, 'Trang tiếp', 'ds_animeviesub', url = p)
    endOfDirectory(HANDLE)
def info_animeviesub(url, img_film, namefilm):
    r = getlink(url, url).text
    try:
        mota = re.search(r'Nội Dung:.*?font>(.*?)<\/td>', r)[1]
    except:
        mota = namefilm
    parse = fromstring(r)
    p = domhtml(parse, './/td[@class="ALL"]')
    split = p.split('\n')
    for k in split:
        thang = k.split('|')
        tentap = thang[0]
        try:
            sv1 = thang[1].strip()
            if sv1.isdigit():
                fname = f'{namefilm} | Việt Sub | Tập {tentap}'
                u1 = f'https://ssplay.net/v/{sv1}.html'
                addDir(fname, img_film, mota, 'svplay_animeviesub', url=u1, name=fname, img_film=img_film, mota=mota)
        except:
            pass
        try:
            sv2 = thang[2].strip()
            if sv2.isdigit():
                fname = f'{namefilm} | Thuyết Minh | Tập {tentap}'
                u2 = f'https://ssplay.net/v/{sv2}.html'
                addDir(fname, img_film, mota, 'svplay_animeviesub', url=u2, name=fname, img_film=img_film, mota=mota)
        except:
            pass
    endOfDirectory(HANDLE)
def svplay_animeviesub(u, name, img_film, mota):
    resp = getlink(u, 'https://anicdn.top/').text
    mplay = re.findall(r'a href=(["\'])(.*?)\1.*?li.*?>(.*?)<', resp)
    for k in mplay:
        tensv = k[2].strip()
        sv = urljoin(u, k[1])
        fname = f'{name} | {tensv}'
        addDir(fname, img_film, mota, 'play_animeviesub', url=sv, name=tensv, is_folder=False)
    endOfDirectory(HANDLE)
def play_animeviesub(u, name):
    resp = getlink(u, 'https://anicdn.top/').text
    if name in ('SD', 'ST', 'MU', 'TV'):
        s = re.search(r'playerInstance(.*?)split', resp)[1]
        p = s.split('|')
        linkplay = f'https://ssplay.net/{p[31]}/{p[48]}.{p[49]}'
        m3u8_file = process_m3u8(linkplay)
        server_port = start_server()
        play_item = ListItem(offscreen=True, path=f'http://127.0.0.1:{server_port}/{m3u8_file}')
    elif name in ('SB', 'SG'):
        s = re.search(r'playerInstance(.*?)split', resp)[1]
        p = s.split('|')
        linkplay = f'https://ssplay.net/{p[50]}/{p[51]}/{p[52]}/{p[34]}/{p[35]}.html'
        m3u8_file = process_m3u8(linkplay)
        server_port = start_server()
        play_item = ListItem(offscreen=True, path=f'http://127.0.0.1:{server_port}/{m3u8_file}')
    elif name == 'CF':
        s = re.search(r'playerInstance(.*?)split', resp)[1]
        p = s.split('|')
        linkplay = f'https://ssplay.net/{p[33]}/{p[52]}/{p[53]}-{p[45]}-{p[34]}/{p[32]}=.{p[21]}'
        m3u8_file = process_m3u8(linkplay)
        server_port = start_server()
        play_item = ListItem(offscreen=True, path=f'http://127.0.0.1:{server_port}/{m3u8_file}')
    elif name == 'EB':
        iframe = re.search(r'iframe.*?src.*?(\'|")(.*?)\1', resp)[2]
        if '?url=' in iframe:
            linkplay = iframe.split('?url=')[1]
            hdr = f'verifypeer=false&User-Agent={UA}'
        else:
            refif = referer(iframe)
            us = f'https://mi3s.top/get.php?u={quote_plus(iframe)}'
            r = getlink(us,'https://mi3s.top/').text
            dhash = re.search(r'data-stream-url.*?(\'|")(.*?)\1', r)[2]
            linkplay = f'{refif}/{dhash}.m3u8'
            hdr = f'verifypeer=false&User-Agent={UA}&Referer={refif}/'
        play_item = ListItem(offscreen=True, path=linkplay)
        play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
        play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
    else:
        #HY, DM
        iframe = re.search(r'iframe.*?src.*?(\'|")(.*?)\1', resp)[2]
        linkplay = resolve(iframe)
        play_item = ListItem(offscreen=True, path=linkplay)
    play_item.setProperty('inputstream', 'inputstream.adaptive')
    setResolvedUrl(HANDLE, True, listitem=play_item)
def search():
    query = Dialog().input(u'Tìm: tên phim ...', type=INPUT_ALPHANUM)
    if query:
        search_history_save(query)
        timkiem(query)
    else:
        find()
def router(paramstring):
    Thread(target=start_server, daemon=True).start()
    params = dict(parse_qsl(paramstring))
    action_map = {
        'animeviesub_theloai': animeviesub_theloai,
        'animeviesub_quocgia': animeviesub_quocgia,
        'filmnew': filmnew,
        'animeviesub_nam': animeviesub_nam,
        'pm_animeviesub': partial(pm_animeviesub, params.get('slug'), params.get('trang_thai'), params.get('ten'), params.get('noi_dung'), params.get('thumb')),
        'cdn_animeviesub': partial(cdn_animeviesub, params.get('url'), params.get('img_film'), params.get('namefilm'), params.get('noi_dung')),
        'ds_animeviesub': partial(ds_animeviesub, params.get('url')),
        'info_animeviesub': partial(info_animeviesub, params.get('url'), params.get('img_film'), params.get('namefilm')),
        'search': search,
        'timkiem': find,
        'timanimeviesub': partial(timkiem, params.get('key')),
        'svplay_animeviesub': partial(svplay_animeviesub, params.get('url'), params.get('name'), params.get('img_film'), params.get('mota')),
        'play_animeviesub': partial(play_animeviesub, params.get('url'), params.get('name')),
    }
    action_map.get(params.get('mode'), main)()
try:
    router(argv[2][1:])
except:
    pass