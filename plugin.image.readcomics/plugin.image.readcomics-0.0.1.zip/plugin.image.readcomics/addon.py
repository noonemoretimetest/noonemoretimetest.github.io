from urllib.parse import urlencode, parse_qsl, quote_plus
from functools import partial
from xbmcplugin import addDirectoryItem, endOfDirectory, setContent
from xbmcaddon import Addon
from base64 import b64encode
from html import unescape
from xbmcvfs import translatePath
from pickle import load, dump
from windows import PagesWindow
import re, sys, os, requests, xbmcgui
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
addon_id = Addon().getAddonInfo('id')
ICON = Addon().getAddonInfo('icon')
PATH = Addon().getAddonInfo('path')
addon_data_dir = os.path.join(translatePath('special://userdata/addon_data'), addon_id)
RESOURCES = PATH + '/resources/media/'
searchimg = RESOURCES +'solid_icons/search.png'
nextimg = RESOURCES + 'nextpage.png'
api = 'https://otruyenapi.com/v1/api'
UA = 'Mozilla/5.0 (Linux; Android 16; Pixel 9 Pro Build/AP4A.241212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/605.1.15 EdgA/140.0.0.0'
def addDir(title, poster, plot, mode, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(plot)
    list_item.setArt({'icon': poster, 'thumb': poster, 'poster': poster, 'banner': poster, 'fanart': poster})
    addDirectoryItem(HANDLE, dir_url, list_item, True)
def getlink(url, ref):
    r = requests.get(url, timeout=30, headers={'user-agent': UA,'referer': ref.encode('utf-8')})
    r.encoding = 'utf-8'
    return r
def get_file_path(filename):
    return os.path.join(addon_data_dir, filename)
def read_file(filename):
    path = get_file_path(filename)
    if not os.path.exists(path):
        return None
    try:
        with open(path, 'rb') as f:
            return load(f)
    except:
        return None
def write_file(filename, data):
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)
    path = get_file_path(filename)
    try:
        with open(path, 'wb') as f:
            dump(data, f)
    except:
        pass
    return path
def search_history_save(search_key):
    if not search_key:
        return
    history = read_file('historys.pkl') or []
    if search_key in history:
        history.remove(search_key)
    elif len(history) >= 20:
        history.pop()
    history.insert(0, search_key)
    write_file('historys.pkl', history)
def search_history_get():
    return read_file('historys.pkl') or []
def find():
    addDir('Tìm truyện', searchimg, 'Tìm truyện', 'search')
    b = search_history_get()
    if b:
        for m in b:
            addDir(m, ICON, m, 'tim_ot', key=m, p=1)
    endOfDirectory(HANDLE)
def timkiem(query, next_page):
    sr = quote_plus(query)
    u = f'{api}/tim-kiem?keyword={sr}'
    ds_ot(u, next_page)
def search():
    query = xbmcgui.Dialog().input(u'Tìm: tên truyện ...', type=xbmcgui.INPUT_ALPHANUM)
    if query:
        search_history_save(query)
        timkiem(query, 1)
    else:
        find()
def main():
    addDir('Tìm truyện', searchimg, 'Tìm truyện', 'timkiem')
    dulieu = {
        'Truyện mới': f'{api}/danh-sach/truyen-moi',
        'Đang phát hành': f'{api}/danh-sach/dang-phat-hanh',
        'Hoàn thành': f'{api}/danh-sach/hoan-thanh',
        'Sắp ra mắt': f'{api}/danh-sach/sap-ra-mat'
        }
    addDir('Thể loại', ICON, 'Thể loại', 'ot_tl')
    for k in dulieu:
        addDir(k, ICON, k, 'ds_ot', url = dulieu[k], p=1)
    endOfDirectory(HANDLE)
def ot_phanloai(phanloai, trang):
    u = f'{api}/{phanloai}'
    r = getlink(u, u).json()['data']['items']
    for k in r:
        ten = k['name']
        addDir(ten, ICON, ten, 'ds_ot', url = f"{api}/{phanloai}/{k['slug']}", p=trang)
    endOfDirectory(HANDLE)
def ds_ot(match, next_page):
    u = f'{match}&page={next_page}' if '?' in match else f'{match}?page={next_page}'
    r = getlink(u, u).json()['data']
    imgcdn = r['APP_DOMAIN_CDN_IMAGE']
    items = r['items']
    has_valid_item = False
    for k in items:
        try:
            chaptersLatest = k['chaptersLatest'][0]['chapter_name']
            name = f"{k['name'].strip()} | Chương {chaptersLatest}"
            thumb_url = f"{imgcdn}/uploads/comics/{k['thumb_url']}"
            addDir(name, thumb_url, name, 'id_ot', idp=k['slug'])
            has_valid_item = True
        except:
            continue
    if has_valid_item:
        tiep = str(int(next_page) + 1)
        addDir(f'Trang {tiep}', nextimg, f'Trang {tiep}', 'ds_ot', url=match, p=tiep)
        endOfDirectory(HANDLE)
    else:
        ds_ot(match, str(int(next_page) + 1))
def id_ot(idp):
    u = f'{api}/truyen-tranh/{idp}'
    r = getlink(u,u).json()['data']
    item = r['item']
    content = unescape(re.sub('<.*?>', '', item['content']))
    chapters = item['chapters']
    imgcdn = r['APP_DOMAIN_CDN_IMAGE']
    thumb_url = f"{imgcdn}/uploads/comics/{item['thumb_url']}"
    for k in chapters:
        server_name = k['server_name']
        server_data = k['server_data']
        for m in server_data:
            filename = m['filename']
            chapter_name = m['chapter_name']
            chapter_api_data = m['chapter_api_data']
            fname = f'{filename} | {server_name} | Chap {chapter_name}'
            addDir(fname, thumb_url, content, 'detail', u=chapter_api_data)
    endOfDirectory(HANDLE)
def detail(u):
    r = getlink(u,u).json()['data']
    domain_cdn = r['domain_cdn']
    d = r['item']
    comic_name = d['comic_name']
    chapter_name = d['chapter_name']
    chapter_path = d['chapter_path']
    chapter_image = d['chapter_image']
    tieude = f'{comic_name} - chap {chapter_name}'
    results = [
        {
            'title': f'Page {m["image_page"]}',
            'link': b64encode(f'{domain_cdn}/{chapter_path}/{m["image_file"]}'.encode()).decode()
        }
        for m in chapter_image
    ]
    window = PagesWindow(title = tieude, pages = results)
    window.doModal()
    del window
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action_map = {
        'detail': partial(detail, params.get('u')),
        'id_ot': partial(id_ot, params.get('idp')),
        'ds_ot': partial(ds_ot, params.get('url'), params.get('p')),
        'ot_tl': partial(ot_phanloai, 'the-loai', 1),
        'tim_ot': partial(timkiem, params.get('key'), int(params.get('p', 0))),
        'search': search,
        'timkiem': find
    }
    action_map.get(params.get('mode'), main)()
router(sys.argv[2][1:])