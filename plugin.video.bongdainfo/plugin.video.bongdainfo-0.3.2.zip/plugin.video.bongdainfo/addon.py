from urllib.parse import urlencode, parse_qsl, urlparse, unquote
from functools import partial
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from bs4 import BeautifulSoup
from json import loads
from sys import argv
from requests import Session
from xbmcgui import ListItem
import re, os
addon_url = argv[0]
HANDLE = int(argv[1])
addon_id = Addon().getAddonInfo('id')
ICON = Addon().getAddonInfo('icon')
xoilacz = 'https://xoilacz.live'
UA = 'Mozilla/5.0 (SMART-TV; LINUX; Tizen 9.0) AppleWebKit/537.36 (KHTML, like Gecko) 120.0.6099.5/9.0 TV Safari/537.36'
def addDir(title, mode, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = ListItem(label=f'{title}')
    list_item.setArt({'icon': ICON, 'thumb': ICON, 'poster': ICON, 'fanart': ICON})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(f'{title}')
    info_tag.setPlot(f'{title}')
    setContent(HANDLE, 'videos')
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref):
    with Session() as s:
        s.headers.update({'user-agent': UA,'referer': ref.encode('utf-8')})
        try:
            r = s.get(url, timeout=20)
        except:
            r = s.get(url, timeout=20, verify=False)
    r.encoding = 'utf-8'
    return r
def domhtml(el, selector, attr=None):
    tag = el.select_one(selector)
    if not tag:
        return ''
    return tag.get(attr, '') if attr else tag.get_text(strip=True)
def domain(url):
    parsed_url = urlparse(url.strip())
    return f'{parsed_url.scheme}://{parsed_url.netloc}' 
def main():
    url = 'https://kutt.it/xoilacz'
    r = getlink(url, url).json()['groups'][0]['channels']
    for k in r:
        name = k['name']
        name = re.sub(r'^[^\w]+', '', name).strip()
        m = re.match(r'(.+?)\s*\|\s*([\d:]+ [\d/]+)\s*\|\s*(.+)', name)
        if m:
            match_name, time_str, commentator = m.groups()
            formatted = f"{time_str} {match_name} | {commentator}"
        else:
            m = re.match(r'(.+?)\s*\|\s*([\d:]+ [\d/]+)', name)
            if m:
                match_name, time_str = m.groups()
                formatted = f"{time_str} {match_name}"
            else:
                formatted = name
        link = f"{xoilacz}{k['id']}"
        addDir(formatted, 'sv_91phut', k = link, t = formatted)
    endOfDirectory(HANDLE)
def sv_91phut(url, name):
    html = getlink(url, xoilacz).text
    soup = BeautifulSoup(html, 'html.parser').select('#tv_links a')
    if soup:
        for k in soup:
            ten = k.get_text(strip=True)
            ep = k['href']
            parsed = urlparse(ep)
            if 'http' in ep and parsed.path and parsed.path != '/':
                addDir(f'{name} | {ten}', 'ifr_bongda', ep = ep, is_folder=False)
    else:
        addDir(name, 'ifr_bongda', ep = url, is_folder=False)
    endOfDirectory(HANDLE)
def ifr_bongda(url):
    resp = getlink(url, url)
    m = re.search(r'var stream_urls.*?([\'"])(.*?)(\1)', resp.text)
    ifr = loads(f'"{m[2]}"')
    r = getlink(ifr, url)
    linkstream = re.search(r'(https?://[^\s"]+\.(m3u8|flv)[^"\']*)', r.text)[1]
    linkplay = re.sub(r'\s+', '%20', linkstream.strip(), flags=re.UNICODE)
    hdr = f"verifypeer=false&User-Agent={unquote(UA)}&Referer={domain(ifr)}/"
    if any((re.search(r':(?!/)', linkplay), ('?' in linkplay))):
        linkplay += f'|{hdr}'
        play_item = ListItem(offscreen=True, path=linkplay)
    else:
        play_item = ListItem(offscreen=True, path=linkplay)
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
        play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
    setResolvedUrl(HANDLE, True, listitem=play_item)
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action_map = {
        'sv_91phut': partial(sv_91phut, params.get('k'), params.get('t')),
        'ifr_bongda': partial(ifr_bongda, params.get('ep'))
    }
    action_map.get(params.get('mode'), main)()
try:
    router(argv[2][1:])
except:
    pass