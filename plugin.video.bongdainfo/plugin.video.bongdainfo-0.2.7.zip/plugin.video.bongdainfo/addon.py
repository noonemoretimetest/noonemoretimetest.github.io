from urllib.parse import urlencode, parse_qsl, urlparse, unquote
from functools import partial
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from json import loads
from random import choice
from time import strptime, strftime
from htmlement import fromstring
import re, sys, os, requests, xbmcgui
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
addon_id = Addon().getAddonInfo('id')
ICON = Addon().getAddonInfo('icon')
UA = 'Mozilla/5.0 (Linux; Android 15; Pixel 9 Pro Build/AP4A.241212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/605.1.15 EdgA/138.0.0.0'
def addDir(title, mode, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=f'{title}')
    list_item.setArt({'icon': ICON, 'thumb': ICON, 'poster': ICON, 'fanart': ICON})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(f'{title}')
    info_tag.setPlot(f'{title}')
    setContent(HANDLE, 'videos')
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref):
    r = requests.get(url, timeout=30, headers={'user-agent': UA,'referer': ref.encode('utf-8')}, verify=False)
    r.encoding = 'utf-8'
    return r
def domhtml(root, xpath, attribute=None, default=None):
    element = root.find(xpath)
    return default if element is None else element.get(attribute, ' '.join(element.itertext()).strip())
def domain(url):
    parsed_url = urlparse(url.strip())
    return f'{parsed_url.scheme}://{parsed_url.netloc}'
def htmlxl(d, u):
    r = getlink(u, d)
    rtext = r.json()['data']['html'] if 'load-more' in u else r.text
    parse = fromstring(rtext)
    matches = []
    # https://xoilacz.live
    if '"grid-matches__item grid-matches__item-match"' in rtext:
        soup = parse.iterfind('.//div[@class="grid-matches__item grid-matches__item-match"]')
        for k in soup:
            league = domhtml(k, './/div[@class="grid-match__league"]')
            home = domhtml(k, './/div[@class="grid-match__team--name grid-match__team--home-name"]')
            away = domhtml(k, './/div[@class="grid-match__team--name grid-match__team--away-name"]')
            blv = domhtml(k, './/div[@class="grid-match__footer-center"]') or ''
            timeRaw = ' '.join(domhtml(k, './/div[@class="grid-match__date"]').split())
            dt = strptime(timeRaw, '%H:%M %d.%m')
            href = domhtml(k, './/a[@class="redirectPopup"]', attribute='href')
            matches.append((dt, f'{d}{href}', league, home, away, blv))
    # https://socolivezz.cc https://vaoroiz.tv
    elif '"grid-matches__item"' in rtext:
        soup = parse.iterfind('.//div[@class="grid-matches__item"]')
        for k in soup:
            league = domhtml(k, './/div[@class="grid-match__league"]')
            home = domhtml(k, './/div[@class="grid-match__team--name grid-match__team--home-name"]')
            away = domhtml(k, './/div[@class="grid-match__team--name grid-match__team--away-name"]')
            blv = domhtml(k, './/div[@class="grid-match__footer-center"]') or ''
            timeRaw = ' '.join(domhtml(k, './/div[@class="grid-match__date"]').split())
            dt = strptime(timeRaw, '%H:%M %d.%m')
            href = domhtml(k, './/a[@class="redirectPopup"]', attribute='href')
            matches.append((dt, f'{d}{href}', league, home, away, blv))
    # https://xoilacxo.cc https://cakhiazz.cc https://rakhoiz.cc
    elif '"main-grid-match data-upcoming-match grid-matches__item "' in rtext:
        soup = parse.iterfind('.//div[@class="main-grid-match data-upcoming-match grid-matches__item "]')
        for k in soup:
            league = domhtml(k, './/div[@class="gmd-match-league"]')
            home = domhtml(k, './/div[@class="gmd-team gmd-home_team text-center"]')
            away = domhtml(k, './/div[@class="gmd-team gmd-away_team text-center"]')
            blv = domhtml(k, './/div[@class="extra-info_one int-blv"]') or ''
            timeRaw = ' '.join(domhtml(k, './/div[@class="grid-match__date gmd-match-date"]').split())
            dt = strptime(timeRaw, '%H:%M - %d/%m')
            href = domhtml(k, './/a[@class="redirectPopup"]', attribute='href')
            matches.append((dt, f'{d}{href}', league, home, away, blv))
    # https://xoilacxyz.cc https://vebozz.cc https://mitomvz.cc
    elif '"main-grid-match data-upcoming-match grid-matches__item"' in rtext:
        soup = parse.iterfind('.//div[@class="main-grid-match data-upcoming-match grid-matches__item"]')
        for k in soup:
            league = domhtml(k, './/div[@class="gmd-match-league"]')
            home = domhtml(k, './/div[@class="gmd-team gmd-home_team text-center"]')
            away = domhtml(k, './/div[@class="gmd-team gmd-away_team text-center"]')
            blv = domhtml(k, './/div[@class="extra-info_one int-blv"]') or ''
            timeRaw = ' '.join(domhtml(k, './/div[@class="grid-match__date gmd-match-date"]').split())
            dt = strptime(timeRaw, '%H:%M - %d/%m')
            href = domhtml(k, './/a[@class="redirectPopup"]', attribute='href')
            matches.append((dt, f'{d}{href}', league, home, away, blv))
    # https://90phutvz.cc
    elif "matches__item  main-grid-match data-upcoming-match" in rtext:
        soup = parse.iterfind('.//div[@class="matches__item  main-grid-match data-upcoming-match"]')
        for k in soup:
            league = domhtml(k, './/div[@class="gmd-match-league"]')
            home = domhtml(k, './/div[@class="gmd-team gmd-home_team text-center"]')
            away = domhtml(k, './/div[@class="gmd-team gmd-away_team text-center"]')
            blv = domhtml(k, './/div[@class="extra-info_one"]') or ''
            timeRaw = ' '.join(domhtml(k, './/div[@class="gmd-match-date"]').split())
            dt = strptime(timeRaw, '%H:%M %d/%m')
            href = domhtml(k, './/a[@class="redirectPopup"]', attribute='href')
            matches.append((dt, f'{d}{href}', league, home, away, blv))
    matches.sort()
    for dt, href, league, home, away, blv in matches:
        mten = f'{strftime("%H:%M %d/%m", dt)} {league} [COLOR yellow]{home} vs {away}[/COLOR]'
        ten = f'{mten} {blv}' if blv else mten
        addDir(ten, 'sv_91phut', k=href, t=mten)    
def main():
    T = {
        'Bóng đá': 'football',
        'Bóng rổ': 'basketball',
        'Tennis': 'tennis',
        'Cầu lông': 'badminton',
        'Bóng chuyền': 'volleyball'
        }
    u = 'https://tvlive.api-football.xyz/tvlive_vn_fb2.txt'
    resp = getlink(u, u)
    matches = re.findall(r'\^([a-zA-Z]+://[^|]+)', resp.text)
    d = domain(choice(matches))
    addDir('Tâm điểm', 'index_91phut', d=d)
    for b in T:
        addDir(b, 'thumuc_91phut', d=d, t=T[b], p=0)
    endOfDirectory(HANDLE)
def index_91phut(d):
    htmlxl(d, d)
    endOfDirectory(HANDLE)
def thumuc_91phut(d, t, p):
    u = f'{d}/sport/{t}/load-more/home/page/{p}/per/20'
    htmlxl(d, u)
    r = getlink(u, d).json()['data']
    if p < (r['pagination']['total_pages'] -1):
        trang = f'{p + 1}'
        ntrang = f'{p + 2}'
        addDir(f'Trang {ntrang}', 'thumuc_91phut', d=d, t=t, p=trang)
    endOfDirectory(HANDLE)
def sv_91phut(url, name):
    resp = getlink(url, url).text
    if '"link-video"' in resp:
        soup = fromstring(resp).iterfind('.//div[@class="link-video"]//a')
        for k in soup:
            ten = ''.join(k.itertext()).strip()
            ep = k.get('href')
            parsed = urlparse(ep)
            if 'http' in ep and parsed.path and parsed.path != '/':
                addDir(f'{name} | {ten}', 'ifr_bongda', ep = ep, t=name, is_folder=False)
    elif '"tv_links"' in resp:
        soup = fromstring(resp).iterfind('.//div[@id="tv_links"]//a')
        for k in soup:
            ten = ''.join(k.itertext()).strip()
            ep = k.get('href')
            parsed = urlparse(ep)
            if 'http' in ep and parsed.path and parsed.path != '/':
                addDir(f'{name} | {ten}', 'ifr_bongda', ep = ep, t=name, is_folder=False)
    else:
        addDir(name, 'ifr_bongda', ep = url, t=name, is_folder=False)
    endOfDirectory(HANDLE)
def ifr_bongda(url):
    resp = getlink(url, url)
    m = re.search(r'var stream_urls.*?([\'"])(.*?)(\1)', resp.text)
    ifr = loads(f'"{m[2]}"')
    r = getlink(ifr, url)
    linkstream = re.search(r'(https?://[^\s"]+\.(m3u8|flv)[^"\']*)', r.text)[1]
    linkplay = re.sub(r'\s+', '%20', linkstream.strip(), flags=re.UNICODE)
    hdr = f"verifypeer=false&User-Agent={unquote(UA)}&Referer={domain(ifr)}/"
    play_item = xbmcgui.ListItem(offscreen=True)
    if any((re.search(r':(?!/)', linkplay), ('?' in linkplay))):
        linkplay += f'|{hdr}'
    else:
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
        play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
    play_item.setPath(linkplay)
    setResolvedUrl(HANDLE, True, listitem=play_item)
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action_map = {
        'index_91phut': partial(index_91phut, params.get('d')),
        'sv_91phut': partial(sv_91phut, params.get('k'), params.get('t')),
        'thumuc_91phut': partial(thumuc_91phut, params.get('d'), params.get('t'), int(params.get('p', 1))),
        'ifr_bongda': partial(ifr_bongda, params.get('ep'))
    }
    action_map.get(params.get('mode'), main)()
try:
    router(sys.argv[2][1:])
except:
    pass