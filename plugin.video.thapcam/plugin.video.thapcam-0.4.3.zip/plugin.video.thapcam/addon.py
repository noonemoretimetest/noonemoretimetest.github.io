from urllib.parse import urlencode, parse_qsl, unquote, urlparse, quote_plus
from functools import partial
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from requests import Session
from datetime import datetime
from pickle import dumps, loads
from base64 import b64encode, b64decode
from collections import defaultdict
import re, sys, requests, xbmcgui
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
addon_name = Addon().getAddonInfo('name')
ICON = Addon().getAddonInfo('icon')
PATH = Addon().getAddonInfo('path')
RESOURCES = PATH + '/media/'
nextimg = RESOURCES + 'next.png'
UA = 'Mozilla/5.0 (Linux; Android 16; Pixel 9 Pro Build/AP4A.261212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/605.1.15 EdgA/140.0.0.0'
def addDir(title, logo, mode, is_folder=True, **kwargs):
    kwargs = {key: b64encode(dumps(value)).decode('utf-8') if isinstance(value, list) else value for key, value in kwargs.items()}
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': logo, 'thumb': logo, 'poster': logo, 'fanart': logo})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(title)
    setContent(HANDLE, 'videos')
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref):
    r = requests.get(url, timeout=20, headers={'user-agent': UA, 'referer': ref.encode('utf-8')})
    r.encoding = 'utf-8'
    return r
def referer(url):
    parsed_url = urlparse(url.strip())
    return f'{parsed_url.scheme}://{parsed_url.netloc}'
def remove_html_tags(text):
    return re.sub(r'<[^>]*>', '', text)
def convert_to_gmt7(time_str):
    hour, minute = map(int, time_str.split(":"))
    time_gmt7 = (hour + 7) % 24
    return f"{time_gmt7:02}:{minute:02}"
def fu(url):
    return requests.get(url, headers={'user-agent': UA, 'referer': url.encode('utf-8')}, allow_redirects=True).url
def play(link, ref=None):
    hdr = f'verifypeer=false&User-Agent={unquote(UA)}'
    linkplay = re.sub(r'\s+', '%20', link.strip(), flags=re.UNICODE)
    if ref:
        hdr += f'&Referer={ref}/'
    play_item = xbmcgui.ListItem(offscreen=True)
    if 'm3u8' in linkplay:
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
        play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
    else:
        linkplay = f'{linkplay}|{hdr}'
    play_item.setPath(linkplay)
    setResolvedUrl(HANDLE, True, listitem=play_item)
def play_nhadai(link):
    d = fu('https://daddylive.sx')
    link = f'{d}embed/stream-{link}.php'
    url2 = re.search(r'iframe src="([^"]*)', getlink(link, d).text)[1]
    ref = referer(url2)
    response = getlink(url2, d).text
    channel_key = re.search(r'(?s) channelKey = \"([^"]*)', response)[1]
    auth_ts = re.search(r'(?s) authTs\s*= \"([^"]*)', response)[1]
    auth_rnd = re.search(r'(?s) authRnd\s*= \"([^"]*)', response)[1]
    auth_sig = re.search(r'(?s) authSig\s*= \"([^"]*)', response)[1]
    auth_sig = quote_plus(auth_sig)
    auth_host = re.search(r'\}\s*fetchWithRetry\(\s*\'([^\']*)', response)[1]
    auth_url = f'{auth_host}{channel_key}&ts={auth_ts}&rnd={auth_rnd}&sig={auth_sig}'
    auth = getlink(auth_url, d).text
    host = re.search(r'(?s)m3u8 =.*?:.*?:.*?".*?".*?"([^"]*)', response)[1]
    server_lookup = re.search(r'n fetchWithRetry\(\s*\'([^\']*)', response)[1]
    server_lookup_url = f"https://{urlparse(url2).netloc}{server_lookup}{channel_key}"
    server_key = getlink(server_lookup_url, d).json()['server_key']
    play_item = xbmcgui.ListItem(offscreen=True)
    play_item.setPath(f'https://{server_key}{host}{server_key}/{channel_key}/mono.m3u8|verifypeer=false&Referer={ref}/&Origin={ref}&User-Agent={unquote(UA)}')
    setResolvedUrl(HANDLE, True, listitem=play_item)
def play_xemlaivb(ids):
    u = f'https://br.vebo.xyz/api/news/vebotv/detail/{ids}'
    r = getlink(u, u).json()['data']
    link = r['video_url']
    linkplay = re.sub(r'\s+', '%20', link.strip(), flags=re.UNICODE)
    play_item = xbmcgui.ListItem(offscreen=True)
    play_item.setPath(linkplay)
    setResolvedUrl(HANDLE, True, listitem=play_item)
def play_xemlaitc(ids):
    u = f'https://q.thapcamn.xyz/api/news/thapcam/detail/{ids}'
    r = getlink(u, u).json()['data']
    link = r['video_url']
    linkplay = re.sub(r'\s+', '%20', link.strip(), flags=re.UNICODE)
    play_item = xbmcgui.ListItem(offscreen=True)
    play_item.setPath(linkplay)
    setResolvedUrl(HANDLE, True, listitem=play_item)
def main():
    addDir('NHÀ ĐÀI', ICON, 'index_nhadai')
    addDir('Xem lại bóng đá', ICON, 'index_xemlaivb', p = 1)
    addDir('Xem lại thể thao', ICON, 'index_xemlaitc', p = 1)
    addDir('Tâm điểm bóng đá', ICON, 'index_vebo')
    addDir('Tâm điểm thể thao', ICON, 'index_cakeo')
    endOfDirectory(HANDLE)
def index_nhadai():
    grouped_results = defaultdict(list)
    d = fu('https://daddylive.sx')
    resp = getlink(f'{d}schedule/schedule-generated.php', d).json()
    for h in resp.values():
        for k in h:
            result = [(f"{convert_to_gmt7(show.get('time')) if show.get('time') else ''} {show.get('event')}",
                       [(ch.get('channel_name', ''), ch.get('channel_id', '')) for ch in show.get('channels', []) if isinstance(ch, dict)])
                      for show in h[k] if any(isinstance(ch, dict) for ch in show.get('channels', []))]            
            if result:
                grouped_results[k].extend(result)
    for k, results in grouped_results.items():
        tenshow = remove_html_tags(k)
        addDir(tenshow, ICON, 'list_nhadai', ids = b64encode(dumps(results)))
    endOfDirectory(HANDLE)
def index_vebo():
    url = 'https://api.vebo.xyz/api/match/vb/featured'
    resp = getlink(url, url).json()['featured']
    for k in resp:
        time = datetime.fromtimestamp(int(k['timestamp'])/1000).strftime('%H:%M')
        blv = ' - '.join(h['name'] for h in k.get('fansites') or [] if h.get('name'))
        namet = f'{time} {k["name"]}'
        tentran = f'[COLOR yellow]{namet}[/COLOR]' if k['match_status'] == 'live' else namet
        tenv = f'{tentran} | {blv}' if blv else tentran
        tenv2 = f'{time} {k["name"]} | {blv}' if blv else f'{time} {k["name"]}'
        logotour = k['tournament']['logo']
        addDir(tenv, logotour, 'list_vebo', idk = k['id'], tentran = tenv2, anhtran = logotour, slug = k['slug'])
    endOfDirectory(HANDLE)
def index_cakeo():
    url = 'https://api.cakeo.xyz/match/live'
    resp = getlink(url, url).json()['data']
    resp_sorted = sorted(resp, key=lambda x: int(x['timestamp']))
    for k in resp_sorted:
        time = datetime.fromtimestamp(int(k['timestamp']) / 1000).strftime('%H:%M')
        blv = ' - '.join(h['name'] for h in k.get('fansites') or [] if h.get('name'))
        nametour = k['tournament']['name']
        namet = f'{time} {k["name"]}'
        namet2 = f'{nametour} | {time} {k["name"]}'
        tentran = f'[COLOR yellow]{namet}[/COLOR]' if k['match_status'] in [1, 2] else namet
        tenv = f'{nametour} | {tentran} | {blv}' if blv else f'{nametour} | {tentran}'
        logotour = k['tournament']['logo'] or ''
        addDir(tenv, logotour, 'list_cakeo', idk = k['id'], tentran = namet2, anhtran = logotour, slug = k['slug'])
    endOfDirectory(HANDLE)
def index_xemlaivb(p):
    d = f'https://br.vebo.xyz/api/news/vebotv/list/{p}'
    resp = getlink(d, d).json()['data']
    try:
        ids = resp['highlight']['id']
        name = resp['highlight']['name']
        img = resp['highlight']['feature_image']
        addDir(name, img, 'play_xemlaivb', ids = ids, is_folder=False)
    except:
        pass
    listp = resp['list']
    for k in listp:
        ids = k['id']
        name = k['name']
        img = k['feature_image']
        addDir(name, img, 'play_xemlaivb', ids = ids, is_folder=False)
    trang = str(int(p) + 1)
    addDir(f'Trang {trang}', nextimg, 'index_xemlaivb', p=trang)
    endOfDirectory(HANDLE)
def index_xemlaitc(p):
    d = f'https://q.thapcamn.xyz/api/news/thapcam/list/{p}'
    resp = getlink(d, d).json()['data']
    try:
        ids = resp['highlight']['id']
        name = resp['highlight']['name']
        img = resp['highlight']['feature_image']
        addDir(name, img, 'play_xemlaitc', ids = ids, is_folder=False)
    except:
        pass
    listp = resp['list']
    for k in listp:
        ids = k['id']
        name = k['name']
        img = k['feature_image']
        addDir(name, img, 'play_xemlaitc', ids = ids, is_folder=False)
    trang = str(int(p) + 1)
    addDir(f'Trang {trang}', nextimg, 'index_xemlaitc', p=trang)
    endOfDirectory(HANDLE)
def list_nhadai(paramsids):
    ids = loads(b64decode(paramsids))
    for k in ids:
        tentran = k[0]
        channel_ids = k[1]
        if len(channel_ids) > 1:
            addDir(tentran, ICON, 'detail_nhadai', ev = b64encode(dumps(channel_ids)), nameid = tentran)
        elif channel_ids:
            addDir(tentran, ICON, 'play_nhadai', link = channel_ids[0][1], is_folder=False)
    endOfDirectory(HANDLE)
def detail_nhadai(paramsev, nameid):
    ev = loads(b64decode(paramsev))
    for k in ev:
        channelname = k[0]
        channelid = k[1]
        ten = f'{nameid} | {channelname}'
        addDir(ten, ICON, 'play_nhadai', link = channelid, is_folder=False)
    endOfDirectory(HANDLE)
def list_vebo(slug, idk, tenm, anhtran):
    urlvb = fu('https://vebo.tv')
    resp = getlink(f'{urlvb}truc-tiep/{slug}-{idk}', urlvb).text
    ref = referer(re.search(r"base_embed_url.*?(['\"])(.*?)(\1)", resp)[2])
    kq = getlink(f'http://api.vebo.xyz/api/match/{idk}/meta', urlvb).json()['data']['play_urls']
    for k in kq:
        tenv = f"{tenm} | {k['name']}"
        addDir(tenv, anhtran, 'play', link = k['url'], ref = f'{ref}/', is_folder=False)
    endOfDirectory(HANDLE)
def list_cakeo(slug, idk, tenm, anhtran):
    urlck = fu('https://cakeo.tv')
    resp = getlink(f'{urlck}truc-tiep/{slug}-{idk}', urlck).text
    ref = referer(re.search(r"base_embed_url.*?(['\"])(.*?)(\1)", resp)[2])
    kq = getlink(f'https://api.cakeo.xyz/match/meta-v2/{idk}', urlck).json()['data']['fansites']
    for k in kq:
        blv = k['name']
        for m in k['play_urls']:
            tenv = f"{tenm} | {blv} | {m['name']}"
            addDir(tenv, anhtran, 'play', link = m['url'], ref = f'{ref}/', is_folder=False)
    endOfDirectory(HANDLE)
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action_map = {
        'index_nhadai': index_nhadai,
        'index_vebo': index_vebo,
        'index_cakeo': index_cakeo,
        'list_nhadai': partial(list_nhadai, params.get('ids')),
        'index_xemlaivb': partial(index_xemlaivb, params.get('p')),
        'index_xemlaitc': partial(index_xemlaitc, params.get('p')),
        'detail_nhadai': partial(detail_nhadai, params.get('ev'), params.get('nameid')),
        'list_vebo': partial(list_vebo, params.get('slug'), params.get('idk'), params.get('tentran'), params.get('anhtran')),
        'list_cakeo': partial(list_cakeo, params.get('slug'), params.get('idk'), params.get('tentran'), params.get('anhtran')),
        'play': partial(play, params.get('link'), params.get('ref')),
        'play_nhadai': partial(play_nhadai, params.get('link')),
        'play_xemlaivb': partial(play_xemlaivb, params.get('ids')),
        'play_xemlaitc': partial(play_xemlaitc, params.get('ids'))
    }
    action_map.get(params.get('mode'), main)()
try:
    router(sys.argv[2][1:])
except:
    pass