from urllib.parse import urlencode, parse_qsl, urlparse, unquote
from functools import partial
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from bs4 import BeautifulSoup
from concurrent.futures import ThreadPoolExecutor, as_completed
from json import loads
from time import strftime, mktime, localtime, time
from sys import argv
from requests import Session
from xbmcgui import ListItem
from random import randint
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import re, os
addon_url = argv[0]
HANDLE = int(argv[1])
addon_id = Addon().getAddonInfo('id')
ICON = Addon().getAddonInfo('icon')
xoilacz = 'https://xoilacz.live'
UA = 'Mozilla/5.0 (SMART-TV; LINUX; Tizen 9.0) AppleWebKit/537.36 (KHTML, like Gecko) 120.0.6099.5/9.0 TV Safari/537.36'
def addDir(title, mode, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = ListItem(label=f'{title}')
    list_item.setArt({'icon': ICON, 'thumb': ICON, 'poster': ICON, 'fanart': ICON})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(f'{title}')
    info_tag.setPlot(f'{title}')
    setContent(HANDLE, 'videos')
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref):
    s = Session()
    retries = Retry(
        total=5,
        connect=5,
        read=5,
        backoff_factor=1,
        status_forcelist=[429, 500, 502, 503, 504, 520, 521, 522, 524, 525, 529],
        allowed_methods=["GET"],
        raise_on_status=False
    )
    adapter = HTTPAdapter(max_retries=retries)
    s.mount("http://", adapter)
    s.mount("https://", adapter)
    s.headers.update({
        'user-agent': UA,
        'referer': ref
    })
    try:
        r = s.get(url, timeout=20)
    except:
        r = s.get(url, timeout=20, verify=False)
    r.encoding = 'utf-8'
    return r
def domhtml(el, selector, attr=None):
    tag = el.select_one(selector)
    if not tag:
        return ''
    return tag.get(attr, '') if attr else tag.get_text(strip=True)
def parse_time_to_timestamp(time_str):
    try:
        now = localtime()
        t_part, d_part = [x.strip() for x in time_str.split('-')]
        h, m = map(int, t_part.split(':'))
        day, month = map(int, d_part.split('.'))
        year = now.tm_year
        t_struct = (year, month, day, h, m, 0, 0, 0, -1)
        ts = mktime(t_struct)
        if ts - time() < -300 * 24 * 3600:
            t_struct = (year + 1, month, day, h, m, 0, 0, 0, -1)
            ts = mktime(t_struct)
        return ts
    except:
        return None
def crawl_recent(sport):
    base = f'{xoilacz}/sport/{sport}/load-more/home/page/{{}}/per/20?tg={randint(100000, 999999)}'
    page = 0
    all_items = []
    now = time()
    cutoff_future = now + 7200
    while True:
        url = base.format(page)
        try:
            res = getlink(url, xoilacz).json()
        except:
            break
        data = res.get('data', {})
        html = data.get('html', '')
        total_pages = data.get('pagination', {}).get('total_pages', 1)
        soup = BeautifulSoup(html, 'html.parser').select('.grid-matches__item')
        if not soup:
            break
        for k in soup:
            timeRaw = domhtml(k, '.grid-match__date')
            ts = parse_time_to_timestamp(timeRaw)
            if not ts:
                continue
            if not (ts <= cutoff_future):
                continue
            home = domhtml(k, '.grid-match__team--home-name')
            away = domhtml(k, '.grid-match__team--away-name')
            league = domhtml(k, '.grid-match__league')
            blv = domhtml(k, '.grid-match-item__footer-center')
            href = domhtml(k, 'a.redirectPopup', 'href')
            all_items.append({
                'sport': sport,
                'league': league,
                'home': home,
                'away': away,
                'blv': blv,
                'time': timeRaw,
                'timestamp': ts,
                'href': href,
            })
        if page + 1 >= total_pages:
            break
        page += 1
    return all_items
def domain(url):
    parsed_url = urlparse(url.strip())
    return f'{parsed_url.scheme}://{parsed_url.netloc}' 
def main():
    sports = ['football', 'basketball', 'tennis', 'volleyball', 'badminton', 'esports']
    all_data = []
    with ThreadPoolExecutor(max_workers=len(sports)) as executor:
        futures = {executor.submit(crawl_recent, s): s for s in sports}
        for future in as_completed(futures):
            sport_name = futures[future]
            try:
                result = future.result()
                all_data.extend(result)
            except:
                pass
    all_data.sort(key=lambda x: x['timestamp'])
    for m in all_data:
        namet = f"{strftime('%H:%M - %d.%m', localtime(m['timestamp']))} | {m['sport']} | {m['home']} vs {m['away']}"
        title = f"{namet} | {m['blv']}" if m['blv'] else namet
        link = f"{xoilacz}{m['href']}"
        addDir(title, 'sv_91phut', k = link, t = namet)
    endOfDirectory(HANDLE)
def sv_91phut(url, name):
    html = getlink(url, xoilacz).text
    soup = BeautifulSoup(html, 'html.parser').select('#tv_links a')
    if soup:
        for k in soup:
            ten = k.get_text(strip=True)
            ep = k['href']
            parsed = urlparse(ep)
            if 'http' in ep and parsed.path and parsed.path != '/':
                addDir(f'{name} | {ten}', 'ifr_bongda', ep = ep, is_folder=False)
    else:
        addDir(name, 'ifr_bongda', ep = url, is_folder=False)
    endOfDirectory(HANDLE)
def ifr_bongda(url):
    resp = getlink(url, url)
    m = re.search(r'var stream_urls.*?([\'"])(.*?)(\1)', resp.text)
    ifr = loads(f'"{m[2]}"')
    r = getlink(ifr, url)
    linkstream = re.search(r'(https?://[^\s"]+\.(m3u8|flv)[^"\']*)', r.text)[1]
    linkplay = re.sub(r'\s+', '%20', linkstream.strip(), flags=re.UNICODE)
    hdr = f"verifypeer=false&User-Agent={unquote(UA)}&Referer={domain(ifr)}/"
    if any((re.search(r':(?!/)', linkplay), ('?' in linkplay))):
        linkplay += f'|{hdr}'
        play_item = ListItem(offscreen=True, path=linkplay)
    else:
        play_item = ListItem(offscreen=True, path=linkplay)
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
        play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
    setResolvedUrl(HANDLE, True, listitem=play_item)
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action_map = {
        'sv_91phut': partial(sv_91phut, params.get('k'), params.get('t')),
        'ifr_bongda': partial(ifr_bongda, params.get('ep'))
    }
    action_map.get(params.get('mode'), main)()
try:
    router(argv[2][1:])
except:
    pass