from urllib.parse import urlencode, parse_qsl, unquote, quote_plus, urlparse, urljoin
from functools import partial
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from pickle import load, dump
from xbmcvfs import translatePath
from htmlement import fromstring
from pathlib import Path
from time import localtime
from sys import argv
from requests import Session
from xbmcgui import ListItem, Dialog, INPUT_ALPHANUM
from threading import Thread
from bottle import Bottle, response
from random import randint
from socket import socket, AF_INET, SOCK_STREAM
from resolveurl import resolve
import re, os
addon_url = argv[0]
HANDLE = int(argv[1])
addon_id = Addon().getAddonInfo('id')
ICON = Addon().getAddonInfo('icon')
PATH = Addon().getAddonInfo('path')
RESOURCES = PATH + '/media/'
searchimg = RESOURCES +'search.png'
nextimg = RESOURCES + 'next.png'
UA = 'Mozilla/5.0 (Linux; Android 16; Pixel 9 Pro Build/AP4A.261212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/605.1.15 EdgA/140.0.0.0'
addon_data_dir = os.path.join(translatePath('special://userdata/addon_data'), addon_id)
app = Bottle()
def addDir(title=None, img=None, plot=None, mode=None, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = ListItem(label=f'{title}')
    list_item.setArt({'icon': img, 'thumb': img, 'poster': img, 'fanart': img})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(f'{title}')
    info_tag.setPlot(f'{plot}')
    setContent(HANDLE, 'videos')
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref):
    with Session() as s:
        s.headers.update({'user-agent': UA,'referer': ref.encode('utf-8')})
        try:
            r = s.get(url, timeout=20)
        except:
            r = s.get(url, timeout=20, verify=False)
    r.encoding = 'utf-8'
    return r
def domhtml(root, xpath, attribute=None, default=None):
    element = root.find(xpath)
    return default if element is None else element.get(attribute, '\n'.join(element.itertext()).strip())
def referer(url):
    parsed_url = urlparse(url.strip())
    return f'{parsed_url.scheme}://{parsed_url.netloc}/'
def get_file_path(filename):
    return os.path.join(addon_data_dir, filename)
def limit_files_in_directory(directory):
    files = sorted(Path(directory).glob('*'), key=os.path.getmtime)
    while len(files) > 5:
        oldest_file = files.pop(0)
        try:
            oldest_file.unlink()
        except Exception as e:
            pass
def get_random_free_port(start=10000, end=65535):
    while True:
        port = randint(start, end)
        with socket(AF_INET, SOCK_STREAM) as s:
            if s.connect_ex(('127.0.0.1', port)) != 0:
                return port
@app.route('/<filename>')
def serve_m3u8(filename):
    path = os.path.join(addon_data_dir, filename)
    if not os.path.exists(path):
        response.status = 404
        return 'Not found'
    response.content_type = 'application/vnd.apple.mpegurl'
    with open(path, 'r', encoding='utf-8') as f:
        return f.read()
def start_server():
    port = get_random_free_port()
    Thread(target=lambda: app.run(host='127.0.0.1', port=port), daemon=True).start()
    return port
def process_m3u8(url):
    lines = getlink(url, url).text.splitlines()
    cleaned_lines = []
    for line in lines:
        if not line.startswith("#"):
            line = urljoin(url, line)
        cleaned_lines.append(line)
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)
    parsed_url = urlparse(url.strip())
    path_parts = [p for p in parsed_url.path.strip('/').split('/') if p]
    if not path_parts:
        path_parts = ['playlist']
    filename_root, _ = os.path.splitext(path_parts[-1])
    path_parts[-1] = f'{filename_root}.m3u8'
    name = '_'.join(path_parts)
    path = os.path.join(addon_data_dir, name)
    with open(path, 'w+', encoding='utf-8') as f:
        f.write('\n'.join(cleaned_lines))
    limit_files_in_directory(addon_data_dir)
    return name
def read_file(filename):
    path = get_file_path(filename)
    if not os.path.exists(path):
        return None
    try:
        with open(path, 'rb') as f:
            return load(f)
    except:
        return None
def write_file(filename, data):
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)
    path = get_file_path(filename)
    try:
        with open(path, 'wb') as f:
            dump(data, f)
    except:
        pass
    return path
def search_history_save(search_key):
    if not search_key:
        return
    history = read_file('historys.pkl') or []
    if search_key in history:
        history.remove(search_key)
    elif len(history) >= 20:
        history.pop()
    history.insert(0, search_key)
    write_file('historys.pkl', history)
def search_history_get():
    return read_file('historys.pkl') or []
def main():
    addDir('Tìm kiếm', searchimg, 'Tìm kiếm', 'timkiem')
    T = {'Thể loại': 'animeviesub_theloai',
        'Năm': 'animeviesub_nam'
        }
    dulieu = {
        'Phim mới': 'https://api-zophim.blogspot.com/',
        'Phim bộ': 'https://api-zophim.blogspot.com/search/label/Series',
        'Phim lẻ': 'https://api-zophim.blogspot.com/search/label/Movie'
        }
    for b in T:
        addDir(b, ICON, b, T[b])
    for k in dulieu:
        addDir(k, ICON, k, 'ds_animeviesub', url = dulieu[k])
    endOfDirectory(HANDLE)
def find():
    addDir('Tìm kiếm', searchimg, 'Tìm kiếm', 'search')
    b = search_history_get()
    if b:
        for m in b:
            addDir(m, searchimg, m, 'timanimeviesub', key = m)
    endOfDirectory(HANDLE)
def timkiem(query):
    sr = quote_plus(query)
    url = f'https://api-zophim.blogspot.com/search?q={sr}'
    ds_animeviesub(url)
def animeviesub_theloai():
    dulieu = {
        'Viễn tưởng': 'https://api-zophim.blogspot.com/search?q=Vi%E1%BB%85n%20T%C6%B0%E1%BB%9Fng',
        'Hành động': 'https://api-zophim.blogspot.com/search?q=H%C3%A0nh%20%C4%90%E1%BB%99ng',
        'Kinh dị': 'https://api-zophim.blogspot.com/search?q=Kinh%20D%E1%BB%8B',
        'Cổ trang': 'https://api-zophim.blogspot.com/search?q=C%E1%BB%95%20Trang',
        'Tình yêu': 'https://api-zophim.blogspot.com/search?q=T%C3%ACnh%20Y%C3%AAu',
        '18 plus': 'https://api-zophim.blogspot.com/search?q=18%20Plus'
        }
    for k in dulieu:
        addDir(k, ICON, k, 'ds_animeviesub', url = dulieu[k])
    endOfDirectory(HANDLE)
def animeviesub_nam():
    namnay = localtime().tm_year
    dulieu = {
        f'{namnay - 9}': f'https://api-zophim.blogspot.com/search?q={namnay - 9}',
        f'{namnay - 8}': f'https://api-zophim.blogspot.com/search?q={namnay - 8}',
        f'{namnay - 7}': f'https://api-zophim.blogspot.com/search?q={namnay - 7}',
        f'{namnay - 6}': f'https://api-zophim.blogspot.com/search?q={namnay - 6}',
        f'{namnay - 5}': f'https://api-zophim.blogspot.com/search?q={namnay - 5}',
        f'{namnay - 4}': f'https://api-zophim.blogspot.com/search?q={namnay - 4}',
        f'{namnay - 3}': f'https://api-zophim.blogspot.com/search?q={namnay - 3}',
        f'{namnay - 2}': f'https://api-zophim.blogspot.com/search?q={namnay - 2}',
        f'{namnay - 1}': f'https://api-zophim.blogspot.com/search?q={namnay - 1}',
        namnay: f'https://api-zophim.blogspot.com/search?q={namnay}&sort=popular'
        }
    for k in dulieu:
        addDir(k, ICON, k, 'ds_animeviesub', url = dulieu[k])
    endOfDirectory(HANDLE)
def ds_animeviesub(u):
    r = getlink(u,u).text
    parse = fromstring(r)
    root = parse.iterfind('.//table[@style]/tr[@onclick]')
    p = domhtml(parse, './/link[@rel="canonical"]', attribute='href')
    for k in root:
        img = domhtml(k, './/img', attribute='src')
        ten = domhtml(k, './/font')
        try:
            m = re.search(r'(\'|")(.*?)\1', k.get('onclick'))
            link = urljoin(u, m[2])
            addDir(ten, img, ten, 'info_animeviesub', url = link, img_film=img, namefilm=ten)
        except:
            pass
    if 'blog-pager-older-link' in r:
        addDir('Trang tiếp', nextimg, 'Trang tiếp', 'ds_animeviesub', url = p)
    endOfDirectory(HANDLE)
def info_animeviesub(url, img_film, namefilm):
    r = getlink(url, url).text
    try:
        mota = re.search(r'Nội Dung:.*?font>(.*?)<\/td>', r)[1]
    except:
        mota = namefilm
    parse = fromstring(r)
    p = domhtml(parse, './/td[@class="ALL"]')
    split = p.split('\n')
    for k in split:
        thang = k.split('|')
        tentap = thang[0]
        try:
            sv1 = thang[1].strip()
            if sv1.isdigit():
                fname = f'{namefilm} | Việt Sub | Tập {tentap}'
                u1 = f'https://ssplay.net/v/{sv1}.html'
                addDir(fname, img_film, mota, 'svplay_animeviesub', url=u1, name=fname, img_film=img_film, mota=mota)
        except:
            pass
        try:
            sv2 = thang[2].strip()
            if sv2.isdigit():
                fname = f'{namefilm} | Thuyết Minh | Tập {tentap}'
                u2 = f'https://ssplay.net/v/{sv2}.html'
                addDir(fname, img_film, mota, 'svplay_animeviesub', url=u2, name=fname, img_film=img_film, mota=mota)
        except:
            pass
    endOfDirectory(HANDLE)
def svplay_animeviesub(u, name, img_film, mota):
    resp = getlink(u, 'https://anicdn.top/').text
    mplay = re.findall(r'a href=(["\'])(.*?)\1.*?li.*?>(.*?)<', resp)
    for k in mplay:
        tensv = k[2].strip()
        sv = urljoin(u, k[1])
        fname = f'{name} | {tensv}'
        addDir(fname, img_film, mota, 'play_animeviesub', url=sv, name=tensv, is_folder=False)
    endOfDirectory(HANDLE)
def play_animeviesub(u, name):
    resp = getlink(u, 'https://anicdn.top/').text
    if name in ('SD', 'ST', 'MU'):
        s = re.search(r'playerInstance(.*?)split', resp)[1]
        p = s.split('|')
        linkplay = f'https://ssplay.net/{p[31]}/{p[48]}.{p[49]}'
        m3u8_file = process_m3u8(linkplay)
        server_port = start_server()
        play_item = ListItem(offscreen=True, path=f'http://127.0.0.1:{server_port}/{m3u8_file}')
    elif name in ('SB', 'SG'):
        s = re.search(r'playerInstance(.*?)split', resp)[1]
        p = s.split('|')
        linkplay = f'https://ssplay.net/{p[50]}/{p[51]}/{p[52]}/{p[34]}/{p[35]}.html'
        m3u8_file = process_m3u8(linkplay)
        server_port = start_server()
        play_item = ListItem(offscreen=True, path=f'http://127.0.0.1:{server_port}/{m3u8_file}')
    elif name == 'CF':
        s = re.search(r'playerInstance(.*?)split', resp)[1]
        p = s.split('|')
        linkplay = f'https://ssplay.net/{p[33]}/{p[52]}/{p[53]}-{p[45]}-{p[34]}/{p[32]}=.{p[21]}'
        m3u8_file = process_m3u8(linkplay)
        server_port = start_server()
        play_item = ListItem(offscreen=True, path=f'http://127.0.0.1:{server_port}/{m3u8_file}')
    elif name in ('DM', 'HY'):
        iframe = re.search(r'iframe.*?src.*?(\'|")(.*?)\1', resp)[2]
        linkplay = resolve(iframe)
        play_item = ListItem(offscreen=True, path=linkplay)
    elif name == 'EB':
        iframe = re.search(r'iframe.*?src.*?(\'|")(.*?)\1', resp)[2]
        refif = referer(iframe)
        us = f'https://mi3s.top/get.php?u={quote_plus(iframe)}'
        r = getlink(us,'https://mi3s.top/').text
        dhash = re.search(r'data-stream-url.*?(\'|")(.*?)\1', r)[2]
        linkplay = f'{refif}/{dhash}.m3u8'
        hdr = f'verifypeer=false&User-Agent={UA}&Referer={refif}/'
        play_item = ListItem(offscreen=True, path=linkplay)
        play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
        play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
    play_item.setProperty('inputstream', 'inputstream.adaptive')
    setResolvedUrl(HANDLE, True, listitem=play_item)
def search():
    query = Dialog().input(u'Tìm: tên phim ...', type=INPUT_ALPHANUM)
    if query:
        search_history_save(query)
        timkiem(query)
    else:
        find()
def router(paramstring):
    Thread(target=start_server, daemon=True).start()
    params = dict(parse_qsl(paramstring))
    action_map = {
        'animeviesub_theloai': animeviesub_theloai,
        'animeviesub_nam': animeviesub_nam,
        'ds_animeviesub': partial(ds_animeviesub, params.get('url')),
        'info_animeviesub': partial(info_animeviesub, params.get('url'), params.get('img_film'), params.get('namefilm')),
        'search': search,
        'timkiem': find,
        'timanimeviesub': partial(timkiem, params.get('key')),
        'svplay_animeviesub': partial(svplay_animeviesub, params.get('url'), params.get('name'), params.get('img_film'), params.get('mota')),
        'play_animeviesub': partial(play_animeviesub, params.get('url'), params.get('name')),
    }
    action_map.get(params.get('mode'), main)()
try:
    router(argv[2][1:])
except:
    pass