from urllib.parse import urlencode, parse_qsl, unquote, urlparse, quote_plus
from functools import partial
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from xbmcvfs import translatePath
from pickle import load, dump
import os, re, sys, xbmcgui, urlquick
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
PATH = Addon().getAddonInfo('path')
ICON = Addon().getAddonInfo('icon')
addon_id = Addon().getAddonInfo('id')
RESOURCES = PATH + '/media/'
searchimg = RESOURCES +'search.png'
nextimg = RESOURCES + 'next.png'
UA = 'OTT Navigator/1.7.3.1 (Linux; Android 15; Pixel 9 Pro Build/AP4A.241212) ExoPlayerLib/2.19.1'
UAM = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/605.1.15 Edg/138.0.0.0'
addon_data_dir = os.path.join(translatePath('special://userdata/addon_data'), addon_id)
sre1 = re.compile(r'\n((http|https|udp|rtp|acestream):(.*?)\n)')
sre2 = re.compile(r'[,](?!.*[,])(.*)')
sre3 = re.compile(r'group-title="(.*?)"')
sre4 = re.compile(r'tvg-logo="(.*?)"')
sre5 = re.compile(r'http-user-agent=(.*?)\n')
sre6 = re.compile(r'http-referrer=(.*?)\n')
sre7 = re.compile(r'license_key=(.*?)\n')
def addDir(title, logo, mode, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': logo, 'thumb': logo, 'poster': logo, 'fanart': logo})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(title)
    setContent(HANDLE, 'videos')
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref, luu):
    r = urlquick.get(url, timeout=30, max_age=luu, headers={'user-agent': UAM,'referer': ref.encode('utf-8')})
    r.encoding = 'utf-8'
    return r
def getlinkip(url, ref):
    r = urlquick.get(url, timeout=30, max_age=600, headers={'user-agent': UA,'accept-encoding':'gzip','referer': ref.encode('utf-8')})
    r.encoding = 'utf-8'
    return r
def referer(url):
    parsed_url = urlparse(url.strip())
    return f'{parsed_url.scheme}://{parsed_url.netloc}/'
def hlsvtv(idx):
    idp = re.sub(r'.*?vtv\.mediacdn\.vn/', 'https://cdn-videos.vtv.vn/', idx) if 'vtv.mediacdn.vn' in idx else f'https://cdn-videos.vtv.vn/{idx}'
    return f'{idp}/master.m3u8'
def domhtml(root, xpath, attribute=None, default=None):
    element = root.find(xpath)
    return default if element is None else element.get(attribute, '\n'.join(element.itertext()).strip())
def get_file_path(filename):
    return os.path.join(addon_data_dir, filename)
def read_file(filename):
    path = get_file_path(filename)
    if not os.path.exists(path):
        return None
    try:
        with open(path, 'rb') as f:
            return load(f)
    except:
        return None
def write_file(filename, data):
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)
    path = get_file_path(filename)
    try:
        with open(path, 'wb') as f:
            dump(data, f)
    except:
        pass
    return path
def search_history_save(search_key):
    if not search_key:
        return
    history = read_file('historys.pkl') or []
    if search_key in history:
        history.remove(search_key)
    elif len(history) >= 20:
        history.pop()
    history.insert(0, search_key)
    write_file('historys.pkl', history)
def search_history_get():
    return read_file('historys.pkl') or []
def find():
    addDir('Tìm kiếm', searchimg, 'search')
    b = search_history_get()
    if b:
        for m in b:
            addDir(m, searchimg, 'timvtv', p=1, key = m)
    endOfDirectory(HANDLE)
def timkiem(query, nextpage):
    search_query = quote_plus(query)
    next_page = int(nextpage)
    u = f'https://vtv.vn/tim-kiem.htm?type=3&page={next_page}&keywords={search_query}'
    resp = getlink(u, u, 600)
    root = resp.parse().iterfind('.//li[@class="tlitem"]/a')
    for k in root:
        logo = domhtml(k, './/img', attribute='src')
        title = k.get('title')
        idplay = k.get('href')
        addDir(title, logo, 'playvtv', url=idplay, is_folder=False)
    trang = str(next_page + 1)
    addDir(f'Trang {trang}', nextimg, 'timvtv', p=trang, key=query)
    endOfDirectory(HANDLE)
def main():
    addDir('Tìm video', searchimg, 'timkiem')
    addDir('Giới thiệu', ICON, 'play', id='https://live.fptplay53.net/fnxhd2/f-channel1_vhls.smil/chunklist.m3u8', is_folder=False)
    dulieu = {
        'VTV live': 'live_vtvvn',
        'Nổi bật': 'dacsac_vtvvn',
        'Video mới': 'list_vtvvn',
        'Tin mới': 'tinmoi_vtvvn',
        'Đề xuất': 'gioithieu_vtvvn'
        }
    T = {'Truyền hình FPT': 'https://raw.githubusercontent.com/ntd249/ntdiptv/main/fptudp',
        'VMTTV': 'https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/vmttv',
        'DakLakTV': 'https://raw.githubusercontent.com/luongtamlong/Dak-Lak-IPTV/main/daklakiptv.m3u',
        'AXT 4K Sport': 'https://raw.githubusercontent.com/MrToBun007/AXT/main/4K-UHD.m3u',
        'AlexDang 4K Sport': 'https://raw.githubusercontent.com/kgasaz/4kuhd/master/sports-channels-4k.m3u',
        'IPTV-ORG All': 'https://iptv-org.github.io/iptv/index.m3u',
        'IPTV-ORG Vietnam': 'https://raw.githubusercontent.com/iptv-org/iptv/refs/heads/master/streams/vn.m3u',
        'IPTV-ORG Category': 'https://iptv-org.github.io/iptv/index.category.m3u',
        'IPTV-ORG Language': 'https://iptv-org.github.io/iptv/index.language.m3u',
        'IPTV-ORG Country': 'https://iptv-org.github.io/iptv/index.country.m3u',
        'IPTV-ORG Region': 'https://iptv-org.github.io/iptv/index.region.m3u'
        }
    for m in dulieu:
        addDir(f'[COLOR yellow]{m}[/COLOR]', ICON, dulieu[m], p=1)
    for k in T:
        addDir(k, ICON, 'list_iptv', id=T[k])
    endOfDirectory(HANDLE)
def search():
    query = xbmcgui.Dialog().input(u'Nhập từ khóa tìm kiếm ...', type=xbmcgui.INPUT_ALPHANUM)
    if query:
        search_history_save(query)
        timkiem(query, 1)
    else:
        find()
def list_vtvvn(p):
    next_page = int(p)
    url = f'https://vtv.vn/timeline-video/0/trang-{next_page}.htm'
    resp = getlink(url, url, 600)
    root = resp.parse().iterfind('.//div[@class="item"]')
    for k in root:
        logo = domhtml(k, './/div[@class="VCSortableInPreviewMode"]', attribute='data-thumb')
        title = domhtml(k, './/h3//a')
        href = domhtml(k, './/div[@type="VideoStream"]', attribute='data-vid')
        play = hlsvtv(href)
        addDir(title, logo, 'play', id=play, ref='https://vtv.vn/', is_folder=False)
    trang = str(next_page + 1)
    addDir(f'Trang {trang}', nextimg, 'list_vtvvn', p=trang)
    endOfDirectory(HANDLE)
def tinmoi_vtvvn(p):
    next_page = int(p)
    url = f'https://vtv.vn/timeline-vod/trang-{next_page}.htm'
    resp = getlink(url, url, 600)
    root = resp.parse().iterfind('.//div[@class="kbwcli-iframe"]//a')
    for k in root:
        logo = domhtml(k, './/img', attribute='src')
        title = k.get('title')
        play = k.get('href')
        addDir(title, logo, 'playvtv', url=play, is_folder=False)
    trang = str(next_page + 1)
    addDir(f'Trang {trang}', nextimg, 'tinmoi_vtvvn', p=trang)
    endOfDirectory(HANDLE)
def dacsac_vtvvn():
    u = 'https://vtv.vn/aj-video-moi-nhat.htm'
    resp = getlink(u, u, 600)
    root = resp.parse().iterfind('.//a[@class="title"]')
    for k in root:
        title = k.get('title')
        play = k.get('href')
        addDir(title, ICON, 'playvtv', url=play, is_folder=False)
    endOfDirectory(HANDLE)
def gioithieu_vtvvn(p):
    next_page = int(p)
    url = f'https://vtv.vn/timeline/88/trang-{next_page}.htm'
    resp = getlink(url, url, 600)
    root = resp.parse().iterfind('.//li')
    for k in root:
        if k.find('.//span[@class="sprite icon_type_video"]') is not None:
            logo = domhtml(k, './/a//img', attribute='src')
            title = domhtml(k, './/h4//a')
            play = domhtml(k, './/h4//a', attribute='href')
            addDir(title, logo, 'playvtv', url=play, is_folder=False)
    trang = str(next_page + 1)
    addDir(f'Trang {trang}', nextimg, 'gioithieu_vtvvn', p=trang)
    endOfDirectory(HANDLE)
def live_vtvvn():
    T = {'VTV1': 'https://live.fptplay53.net/fnxch2/vtv1hd_abr.smil/chunklist.m3u8',
        'VTV2': 'https://live.fptplay53.net/fnxch2/vtv2hd_abr.smil/chunklist.m3u8',
        'VTV3': 'https://live.fptplay53.net/fnxch2/vtv3hd_abr.smil/chunklist.m3u8',
        'VTV4': 'https://live.fptplay53.net/fnxch2/vtv4hd_abr.smil/chunklist.m3u8',
        'VTV5': 'https://live.fptplay53.net/epzch2/vtv5hd_abr.smil/chunklist.m3u8',
        'VTV5 Tây Nam Bộ': 'https://live.fptplay53.net/fnxhd1/vtv5tnb_vhls.smil/chunklist.m3u8',
        'VTV5 Tây Nguyên': 'https://live.fptplay53.net/fnxhd1/vtv5taynguyen_vhls.smil/chunklist.m3u8',
        'VTV Cần Thơ': 'https://live.fptplay53.net/fnxch2/vtvcantho_abr.smil/chunklist.m3u8',
        'VTV7': 'https://live.fptplay53.net/fnxhd1/vtv7hd_vhls.smil/chunklist.m3u8',
        'VTV8': 'https://live.fptplay53.net/epzhd1/vtv8hd_vhls.smil/chunklist.m3u8',
        'VTV9': 'https://live.fptplay53.net/epzch2/vtv9hd_abr.smil/chunklist.m3u8'
        }
    for k in T:
        addDir(k, ICON, 'play', id=T[k], is_folder=False)
    endOfDirectory(HANDLE)
def list_iptv(url):
    addDir('TẤT CẢ CÁC KÊNH', ICON, 'little_iptv', id=url)
    texturl = getlinkip(url, url).text
    group = re.finditer(r'group-title="(.*?)"', texturl)
    ld = list(dict.fromkeys(m[1] for m in group))
    um = []
    um = [k for tk in ld for k in (tk.split(';') if ';' in tk else [tk]) if k != '' and k not in um]
    for p in um:
        addDir(p, ICON, 'info_iptv', id=url, tk=p)
    endOfDirectory(HANDLE)
def info_iptv(url, tk):
    texturl = getlinkip(url, url).text
    ketqua = re.sub(r'(#EXTM3U|#[^EX|^KODI])(.*)', '', texturl).split('#EXTINF')
    for kq in ketqua:
        s1 = sre1.search(kq)
        s2 = sre2.search(kq)
        s7 = sre7.search(kq)
        if s1 and s2 and any(((not s7 and f'group-title="{tk}"' in kq and ';' not in kq), (tk in kq and ';' in kq))):
            s4 = sre4.search(kq)
            s5 = sre5.search(kq)
            s6 = sre6.search(kq)
            logo = s4[1] if s4 else ICON
            user = s5[1] if s5 else UA
            ref = s6[1] if s6 else ''
            addDir(s2[1], logo, 'play', id=s1[1], ref=ref, user=user, is_folder=False)
    endOfDirectory(HANDLE)
def little_iptv(url):
    texturl = getlinkip(url, url).text
    ketqua = re.sub(r'(#EXTM3U|#[^EX|^KODI])(.*)', '', texturl).split('#EXTINF')
    for kq in ketqua:
        s1 = sre1.search(kq)
        s2 = sre2.search(kq)
        s7 = sre7.search(kq)
        if s1 and s2 and not s7:
            s3 = sre3.search(kq)
            s4 = sre4.search(kq)
            s5 = sre5.search(kq)
            s6 = sre6.search(kq)
            nhomkenh = s3[1] if s3 else 'TỔNG HỢP'
            logo = s4[1] if s4 else ICON
            user = s5[1] if s5 else UA
            ref = s6[1] if s6 else ''
            tenm = f'{s2[1]} - {nhomkenh}'
            addDir(tenm, logo, 'play', id=s1[1], ref=ref, user=user, is_folder=False)
    endOfDirectory(HANDLE)
def playvtv(u):
    url = f"https://vtv.vn/{u}" if u.startswith('/') else u
    resp = getlink(url, url, -1)
    vfile = hlsvtv(domhtml(resp.parse(), './/div[@type="VideoStream"]', attribute='data-vid'))
    linkplay = re.sub(r'\s+', '%20', vfile.strip(), flags=re.UNICODE)
    hdr = f'verifypeer=false&User-Agent={UAM}&Referer=https://vtv.vn/'
    play_item = xbmcgui.ListItem(offscreen=True)
    play_item.setProperty('inputstream', 'inputstream.adaptive')
    play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
    play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
    play_item.setPath(linkplay)
    setResolvedUrl(HANDLE, True, listitem=play_item)
def play(idp, ref=None, user=None):
    linkplay = re.sub(r'\s+', '%20', idp.strip(), flags=re.UNICODE)
    user = unquote(user)
    play_item = xbmcgui.ListItem(offscreen=True)
    if 'm3u8' in linkplay:
        hdr = f'verifypeer=false&User-Agent={user}'
        if ref:
            hdr += f'&Referer={referer(ref)}'
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
        play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
        play_item.setPath(linkplay)
    play_item.setPath(linkplay)
    setResolvedUrl(HANDLE, True, listitem=play_item)
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action_map = {
        'search': search,
        'timkiem': find,
        'timvtv': partial(timkiem, params.get('key'), params.get('p')),
        'list_vtvvn': partial(list_vtvvn, params.get('p')),
        'tinmoi_vtvvn': partial(tinmoi_vtvvn, params.get('p')),
        'dacsac_vtvvn': dacsac_vtvvn,
        'live_vtvvn': live_vtvvn,
        'gioithieu_vtvvn': partial(gioithieu_vtvvn, params.get('p')),
        'list_iptv': partial(list_iptv, params.get('id')),
        'info_iptv': partial(info_iptv, params.get('id'), params.get('tk')),
        'little_iptv': partial(little_iptv, params.get('id')),
        'playvtv': partial(playvtv, params.get('url')),
        'play': partial(play, params.get('id'), params.get('ref'), params.get('user', UA))
    }
    action_map.get(params.get('mode'), main)()
try:
    router(sys.argv[2][1:])
except:
    pass