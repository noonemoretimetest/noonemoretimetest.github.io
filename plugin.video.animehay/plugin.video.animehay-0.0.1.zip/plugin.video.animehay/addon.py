from urllib.parse import urlencode, parse_qsl, unquote, quote_plus, urlparse
from functools import partial
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from pickle import load, dump
from xbmcvfs import translatePath
from htmlement import fromstring
from base64 import b64encode
from time import localtime
import re, sys, os, requests, xbmcgui
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
addon_id = Addon().getAddonInfo('id')
ICON = Addon().getAddonInfo('icon')
PATH = Addon().getAddonInfo('path')
RESOURCES = PATH + '/media/'
searchimg = RESOURCES +'search.png'
nextimg = RESOURCES + 'next.png'
UA = 'Mozilla/5.0 (Linux; Android 16; Pixel 9 Pro Build/AP4A.261212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/605.1.15 EdgA/140.0.0.0'
addon_data_dir = os.path.join(translatePath('special://userdata/addon_data'), addon_id)
def addDir(title=None, img=None, plot=None, mode=None, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=f'{title}')
    list_item.setArt({'icon': img, 'thumb': img, 'poster': img, 'fanart': img})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(f'{title}')
    info_tag.setPlot(f'{plot}')
    setContent(HANDLE, 'videos')
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref):
    r = requests.get(url, timeout=30, headers={'user-agent': UA,'referer': ref.encode('utf-8')})
    r.encoding = 'utf-8'
    return r
def domhtml(root, xpath, attribute=None, default=None):
    element = root.find(xpath)
    return default if element is None else element.get(attribute, '\n'.join(element.itertext()).strip())
def referer(url):
    parsed_url = urlparse(url.strip())
    return f'{parsed_url.scheme}://{parsed_url.netloc}/'
def get_file_path(filename):
    return os.path.join(addon_data_dir, filename)
def read_file(filename):
    path = get_file_path(filename)
    if not os.path.exists(path):
        return None
    try:
        with open(path, 'rb') as f:
            return load(f)
    except:
        return None
def write_file(filename, data):
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)
    path = get_file_path(filename)
    try:
        with open(path, 'wb') as f:
            dump(data, f)
    except:
        pass
    return path
def search_history_save(search_key):
    if not search_key:
        return
    history = read_file('historys.pkl') or []
    if search_key in history:
        history.remove(search_key)
    elif len(history) >= 20:
        history.pop()
    history.insert(0, search_key)
    write_file('historys.pkl', history)
def search_history_get():
    return read_file('historys.pkl') or []
def encode_year(nam):
    data = [[], [nam], [], []]
    data_str = str(data)
    return b64encode(data_str.encode()).decode()
def fanm():
    u = 'https://ahay.in'
    r = getlink(u,u).text
    return re.search(r'new_domain.*?(\'|")(.*?)\1', r)[2]
def main():
    uanmhay = fanm()
    addDir('Tìm kiếm', searchimg, 'Tìm kiếm', 'timkiem')
    T = {'Thể loại': 'animehay_theloai',
        'Trạng thái': 'animehay_trangthai',
        'Năm': 'animehay_nam'
        }
    dulieu = {
        'Phim mới': f'{uanmhay}phim-moi-cap-nhap/',
        'Phim lẻ': f'{uanmhay}loc-phim/W1tdLFtdLFs5OTk5XSxbXV0=/'
        }
    for b in T:
        addDir(b, ICON, b, T[b])
    for k in dulieu:
        addDir(k, ICON, k, 'ds_animehay', url = dulieu[k], p=1)
    endOfDirectory(HANDLE)
def find():
    addDir('Tìm kiếm', searchimg, 'Tìm kiếm', 'search')
    b = search_history_get()
    if b:
        for m in b:
            addDir(m, searchimg, m, 'timanimehay', key = m)
    endOfDirectory(HANDLE)
def timkiem(query):
    uanmhay = fanm()
    sr = quote_plus(query)
    url = f'{uanmhay}tim-kiem/{sr}/'
    ds_animehay(url, 1)
def animehay_theloai():
    uanmhay = fanm()
    dulieu = {
        'Anime': f'{uanmhay}the-loai/anime-1/',
        'Hành động': f'{uanmhay}the-loai/hanh-dong-2/',
        'Hài hước': f'{uanmhay}the-loai/hai-huoc-3/',
        'Tình cảm': f'{uanmhay}the-loai/tinh-cam-4/',
        'Harem': f'{uanmhay}the-loai/harem-5/',
        'Bí ẩn': f'{uanmhay}the-loai/bi-an-6/',
        'Bi kịch': f'{uanmhay}the-loai/bi-kich-7/',
        'Giả tưởng': f'{uanmhay}the-loai/gia-tuong-8/',
        'Học đường': f'{uanmhay}the-loai/hoc-duong-9/',
        'Đời thường': f'{uanmhay}the-loai/doi-thuong-10/',
        'Võ thuật': f'{uanmhay}the-loai/vo-thuat-11/',
        'Trò chơi': f'{uanmhay}the-loai/tro-choi-12/',
        'Thám tử': f'{uanmhay}the-loai/tham-tu-13/',
        'Lịch sử': f'{uanmhay}the-loai/lich-su-14/',
        'Siêu năng lực': f'{uanmhay}the-loai/sieu-nang-luc-15/',
        'Shounen': f'{uanmhay}the-loai/shounen-16/',
        'Shounen AI': f'{uanmhay}the-loai/shounen-ai-17/',
        'Shoujo': f'{uanmhay}the-loai/shoujo-18/',
        'Shoujo AI': f'{uanmhay}the-loai/shoujo-ai-19/',
        'Thể thao': f'{uanmhay}the-loai/the-thao-20/',
        'Âm nhạc': f'{uanmhay}the-loai/am-nhac-21/',
        'Psychological': f'{uanmhay}the-loai/psychological-22/',
        'Mecha': f'{uanmhay}the-loai/mecha-23/',
        'Quân đội': f'{uanmhay}the-loai/quan-doi-24/',
        'Drama': f'{uanmhay}the-loai/drama-25/',
        'Seinen': f'{uanmhay}the-loai/seinen-26/',
        'Siêu nhiên': f'{uanmhay}the-loai/sieu-nhien-27/',
        'Phiêu lưu': f'{uanmhay}the-loai/phieu-luu-28/',
        'Kinh dị': f'{uanmhay}the-loai/kinh-di-29/',
        'Ma cà rồng': f'{uanmhay}the-loai/ma-ca-rong-30/',
        'Tokusatsu': f'{uanmhay}the-loai/tokusatsu-31/',
        'Samurai': f'{uanmhay}the-loai/samurai-32/',
        'Viễn tưởng': f'{uanmhay}the-loai/vien-tuong-33/',
        'CN Animation': f'{uanmhay}the-loai/cn-animation-34/',
        'Tiên hiệp': f'{uanmhay}the-loai/tien-hiep-35/',
        'Kiếm hiệp': f'{uanmhay}the-loai/kiem-hiep-36/',
        'Xuyên không': f'{uanmhay}the-loai/xuyen-khong-37/',
        'Trùng sinh': f'{uanmhay}the-loai/trung-sinh-38/',
        'Huyền ảo': f'{uanmhay}the-loai/huyen-ao-39/',
        '[CNA] Ngôn tình': f'{uanmhay}the-loai/cna-ngon-tinh-40/',
        'Dị giới': f'{uanmhay}the-loai/di-gioi-41/',
        '[CNA] Hài hước': f'{uanmhay}the-loai/cna-hai-huoc-42/',
        'Đam mỹ': f'{uanmhay}the-loai/dam-my-43/',
        'Võ hiệp': f'{uanmhay}the-loai/vo-hiep-44/',
        'Ecchi': f'{uanmhay}the-loai/ecchi-45/',
        'Demon': f'{uanmhay}the-loai/demon-46/',
        'Live Action': f'{uanmhay}the-loai/live-action-47/',
        'Thriller': f'{uanmhay}the-loai/thriller-48/',
        'Khoa huyễn': f'{uanmhay}the-loai/khoa-huyen-49/',
    }
    for k in dulieu:
        addDir(k, ICON, k, 'ds_animehay', url = dulieu[k], p=1)
    endOfDirectory(HANDLE)
def animehay_trangthai():
    uanmhay = fanm()
    dulieu = {
            'Hoàn thành': f'{uanmhay}loc-phim/W1tdLFtdLFtdLFsxXV0=/',
            'Đang tiến hành': f'{uanmhay}loc-phim/W1tdLFtdLFtdLFswXV0=/'
        }
    for k in dulieu:
        addDir(k, ICON, k, 'ds_animehay', url = dulieu[k], p=1)
    endOfDirectory(HANDLE)
def animehay_nam():
    uanmhay = fanm()
    namnay = localtime().tm_year
    dulieu = {
        'Trước 2014': f'{uanmhay}loc-phim/W1tdLFsxMTExXSxbXSxbXV0=/',
        f'{namnay - 10}': f'{uanmhay}loc-phim/{encode_year(namnay - 10)}/',
        f'{namnay - 9}': f'{uanmhay}loc-phim/{encode_year(namnay - 9)}/',
        f'{namnay - 8}': f'{uanmhay}loc-phim/{encode_year(namnay - 8)}/',
        f'{namnay - 7}': f'{uanmhay}loc-phim/{encode_year(namnay - 7)}/',
        f'{namnay - 6}': f'{uanmhay}loc-phim/{encode_year(namnay - 6)}/',
        f'{namnay - 5}': f'{uanmhay}loc-phim/{encode_year(namnay - 5)}/',
        f'{namnay - 4}': f'{uanmhay}loc-phim/{encode_year(namnay - 4)}/',
        f'{namnay - 3}': f'{uanmhay}loc-phim/{encode_year(namnay - 3)}/',
        f'{namnay - 2}': f'{uanmhay}loc-phim/{encode_year(namnay - 2)}/',
        f'{namnay - 1}': f'{uanmhay}loc-phim/{encode_year(namnay - 1)}/',
        namnay: f'{uanmhay}tim-nang-cao/?status=&season=&year={namnay}&sort=popular'
        }
    for k in dulieu:
        addDir(k, ICON, k, 'ds_animehay', url = dulieu[k], p=1)
    endOfDirectory(HANDLE)
def ds_animehay(url, next_page):
    u = f"{url}trang-{next_page}.html"
    r = getlink(u, u).text
    npage = f'{next_page + 1}'
    if 'movies-list' in r:
        parse = fromstring(r)
        root = parse.iterfind('.//div[@class="movie-item"]//a[@title]')
        for k in root:
            img = domhtml(k, './/img', attribute='src')
            ten = domhtml(k, './/div[@class="name-movie"]')
            link = k.get('href')
            addDir(ten, img, ten, 'info_animehay', url = link, img_film=img, namefilm=ten)
        if f'/trang-{npage}.html' in r:
            tentrang = f'Trang {npage}'
            addDir(tentrang, nextimg, tentrang, 'ds_animehay', url = url, p=npage)
    endOfDirectory(HANDLE)
def info_animehay(url, img_film, namefilm):
    r = getlink(url,url).text
    parse = fromstring(r)
    fplot = parse.iterfind('.//div[@class="desc ah-frame-bg"]')
    plot = ''.join(
        '\n'.join(child_div.itertext()).strip()
        for parent_div in fplot
        for idx, child_div in enumerate(parent_div.iterfind('./div'))
        if idx != 0
    )
    root = parse.iterfind('.//div[@class="list-item-episode scroll-bar"]//a')
    root2 = parse.iterfind('.//div[@class="scroll-bar"]//a')
    for k in root:
        title = ''.join(k.itertext()).strip()
        idp = k.get('href')
        fname = f'{namefilm} | {title}'
        addDir(fname, img_film, plot, 'play_animehay', idp = idp, is_folder=False)
    if root2:
        for m in root2:
            title2 = ''.join(m.itertext()).strip()
            movie_url = m.get('href')
            addDir(title2, img_film, title2, 'info_animehay', url = movie_url, img_film=img_film, namefilm=title2)
    endOfDirectory(HANDLE)
def play_animehay(idp):
    r = getlink(idp,idp).text
    linkstream = re.search(r'(https?://[^\s"]+\.m3u8[^"\']*)', r)[1]
    linkplay = re.sub(r'\s+', '%20', linkstream.strip(), flags=re.UNICODE)
    play_item = xbmcgui.ListItem(offscreen=True)
    play_item.setProperty('inputstream', 'inputstream.adaptive')
    play_item.setPath(linkplay)
    setResolvedUrl(HANDLE, True, listitem=play_item)
def search():
    query = xbmcgui.Dialog().input(u'Tìm: tên phim ...', type=xbmcgui.INPUT_ALPHANUM)
    if query:
        search_history_save(query)
        timkiem(query)
    else:
        find()
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action_map = {
        'animehay_theloai': animehay_theloai,
        'animehay_trangthai': animehay_trangthai,
        'animehay_nam': animehay_nam,
        'ds_animehay': partial(ds_animehay, params.get('url'), int(params.get('p', 1))),
        'info_animehay': partial(info_animehay, params.get('url'), params.get('img_film'), params.get('namefilm')),
        'search': search,
        'timkiem': find,
        'timanimehay': partial(timkiem, params.get('key')),
        'play_animehay': partial(play_animehay, params.get('idp')),
    }
    action_map.get(params.get('mode'), main)()
try:
    router(sys.argv[2][1:])
except:
    pass