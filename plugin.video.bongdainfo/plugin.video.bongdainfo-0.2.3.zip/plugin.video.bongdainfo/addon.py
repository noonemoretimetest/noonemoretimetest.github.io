from urllib.parse import urlencode, parse_qsl, urlparse, unquote
from functools import partial
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from json import loads
from random import choice
from time import strptime, strftime
import re, sys, os, urlquick, xbmcgui
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
addon_id = Addon().getAddonInfo('id')
ICON = Addon().getAddonInfo('icon')
UA = 'Mozilla/5.0 (Linux; Android 15; Pixel 9 Pro Build/AP4A.241212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/605.1.15 EdgA/138.0.0.0'
def addDir(title, mode, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': ICON, 'thumb': ICON, 'poster': ICON, 'fanart': ICON})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(title)
    setContent(HANDLE, 'videos')
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref, luu):
    r = urlquick.get(url, timeout=30, max_age=luu, headers={'user-agent': UA,'referer': ref.encode('utf-8')}, verify=False)
    r.encoding = 'utf-8'
    return r
def domhtml(root, xpath, attribute=None, default=None):
    element = root.find(xpath)
    return default if element is None else element.get(attribute, ' '.join(element.itertext()).strip())
def domain(url):
    parsed_url = urlparse(url.strip())
    return f'{parsed_url.scheme}://{parsed_url.netloc}'
def main():
    u = 'https://tvlive.api-football.xyz/tvlive_vn_fb2.txt'
    resp = getlink(u, u, 400)
    matches = re.findall(r'\^([a-zA-Z]+://[^|]+)', resp.text)
    d = domain(choice(matches))
    r = getlink(d, d, 400)
    matches = []
    if '"grid-matches__item grid-matches__item-match"' in r.text:
        soup = r.parse().iterfind('.//div[@class="grid-matches__item grid-matches__item-match"]')
        for k in soup:
            home = domhtml(k, './/div[@class="grid-match__team--name grid-match__team--home-name"]')
            away = domhtml(k, './/div[@class="grid-match__team--name grid-match__team--away-name"]')
            blv = domhtml(k, './/div[@class="grid-match__footer-center"]') or ''
            timeRaw = ' '.join(domhtml(k, './/div[@class="grid-match__date"]').split())
            dt = strptime(timeRaw, '%H:%M %d.%m')
            href = domhtml(k, './/a[@class="redirectPopup"]', attribute='href')
            matches.append((dt, f'{d}{href}', home, away, blv))
    elif '"grid-matches__item"' in r.text:
        soup = r.parse().iterfind('.//div[@class="grid-matches__item"]')
        for k in soup:
            home = domhtml(k, './/div[@class="grid-match__team--name grid-match__team--home-name"]')
            away = domhtml(k, './/div[@class="grid-match__team--name grid-match__team--away-name"]')
            blv = domhtml(k, './/div[@class="grid-match__footer-center"]') or ''
            timeRaw = ' '.join(domhtml(k, './/div[@class="grid-match__date"]').split())
            dt = strptime(timeRaw, '%H:%M %d.%m')
            href = domhtml(k, './/a[@class="redirectPopup"]', attribute='href')
            matches.append((dt, f'{d}{href}', home, away, blv))
    elif '"main-grid-match data-upcoming-match grid-matches__item "' in r.text:
        soup = r.parse().iterfind('.//div[@class="main-grid-match data-upcoming-match grid-matches__item "]')
        for k in soup:
            home = domhtml(k, './/div[@class="gmd-team gmd-home_team text-center"]')
            away = domhtml(k, './/div[@class="gmd-team gmd-away_team text-center"]')
            blv = domhtml(k, './/div[@class="extra-info_one int-blv"]') or ''
            timeRaw = ' '.join(domhtml(k, './/div[@class="grid-match__date gmd-match-date"]').split())
            dt = strptime(timeRaw, '%H:%M - %d/%m')
            href = domhtml(k, './/a[@class="redirectPopup"]', attribute='href')
            matches.append((dt, f'{d}{href}', home, away, blv))
    elif '"main-grid-match data-upcoming-match grid-matches__item"' in r.text:
        soup = r.parse().iterfind('.//div[@class="main-grid-match data-upcoming-match grid-matches__item"]')
        for k in soup:
            home = domhtml(k, './/div[@class="gmd-team gmd-home_team text-center"]')
            away = domhtml(k, './/div[@class="gmd-team gmd-away_team text-center"]')
            blv = domhtml(k, './/div[@class="extra-info_one int-blv"]') or ''
            timeRaw = ' '.join(domhtml(k, './/div[@class="grid-match__date gmd-match-date"]').split())
            dt = strptime(timeRaw, '%H:%M - %d/%m')
            href = domhtml(k, './/a[@class="redirectPopup"]', attribute='href')
            matches.append((dt, f'{d}{href}', home, away, blv))
    elif "matches__item  main-grid-match data-upcoming-match" in r.text:
        soup = r.parse().iterfind('.//div[@class="matches__item  main-grid-match data-upcoming-match"]')
        for k in soup:
            home = domhtml(k, './/div[@class="gmd-team gmd-home_team text-center"]')
            away = domhtml(k, './/div[@class="gmd-team gmd-away_team text-center"]')
            blv = domhtml(k, './/div[@class="extra-info_one"]') or ''
            timeRaw = ' '.join(domhtml(k, './/div[@class="gmd-match-date"]').split())
            dt = strptime(timeRaw, '%H:%M %d/%m')
            href = domhtml(k, './/a[@class="redirectPopup"]', attribute='href')
            matches.append((dt, f'{d}{href}', home, away, blv))
    matches.sort()
    for dt, href, home, away, blv in matches:
        ten = f'{strftime("%H:%M %d/%m", dt)} {home} vs {away} | {blv}' if blv else f'{strftime("%H:%M %d/%m", dt)} {home} vs {away}'
        addDir(ten, 'sv_91phut', k=href, t=ten)
    endOfDirectory(HANDLE)
def sv_91phut(url, name):
    resp = getlink(url, url, 400)
    if '"link-video"' in resp.text:
        soup = resp.parse().iterfind('.//div[@class="link-video"]//a')
        for k in soup:
            ten = ''.join(k.itertext()).strip()
            ep = k.get('href')
            parsed = urlparse(ep)
            if 'http' in ep and parsed.path and parsed.path != '/':
                addDir(f'{name} | {ten}', 'ifr_bongda', ep = ep, t=name, is_folder=False)
    elif '"tv_links"' in resp.text:
        soup = resp.parse().iterfind('.//div[@id="tv_links"]//a')
        for k in soup:
            ten = ''.join(k.itertext()).strip()
            ep = k.get('href')
            parsed = urlparse(ep)
            if 'http' in ep and parsed.path and parsed.path != '/':
                addDir(f'{name} | {ten}', 'ifr_bongda', ep = ep, t=name, is_folder=False)
    else:
        addDir(name, 'ifr_bongda', ep = url, t=name, is_folder=False)
    endOfDirectory(HANDLE)
def ifr_bongda(url):
    resp = getlink(url, url, -1)
    m = re.search(r'var stream_urls.*?([\'"])(.*?)(\1)', resp.text)
    ifr = loads(f'"{m[2]}"')
    r = getlink(ifr, url, -1)
    linkstream = re.search(r'(https?://[^\s"]+\.(m3u8|flv)[^"\']*)', r.text)[1]
    linkplay = re.sub(r'\s+', '%20', linkstream.strip(), flags=re.UNICODE)
    hdr = f"verifypeer=false&User-Agent={unquote(UA)}&Referer={domain(ifr)}/"
    play_item = xbmcgui.ListItem(offscreen=True)
    if any((re.search(r':(?!/)', linkplay), ('?' in linkplay))):
        linkplay += f'|{hdr}'
    else:
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
        play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
    play_item.setPath(linkplay)
    setResolvedUrl(HANDLE, True, listitem=play_item)
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action_map = {
        'sv_91phut': partial(sv_91phut, params.get('k'), params.get('t')),
        'ifr_bongda': partial(ifr_bongda, params.get('ep'))
    }
    action_map.get(params.get('mode'), main)()
try:
    router(sys.argv[2][1:])
except:
    pass