from urllib.parse import urlencode, parse_qsl, unquote
from functools import partial
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from requests import Session
from time import strptime, strftime, localtime, mktime
from xbmcgui import ListItem
from sys import argv
import re
addon_url = argv[0]
HANDLE = int(argv[1])
ICON = Addon().getAddonInfo('icon')
UA = 'Mozilla/5.0 (Linux; Android 16; Pixel 9 Pro Build/AP4A.261212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/605.1.15 EdgA/140.0.0.0'
def addDir(title, mode, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = ListItem(label=f'{title}')
    list_item.setArt({'icon': ICON, 'thumb': ICON, 'poster': ICON, 'fanart': ICON})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(f'{title}')
    info_tag.setPlot(f'{title}')
    setContent(HANDLE, 'videos')
    list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, False)
def getlink(url):
    with Session() as s:
        s.headers.update({'user-agent': UA, 'referer': url.encode('utf-8')})
        try:
            r = s.get(url, timeout=20)
        except:
            r = s.get(url, timeout=20, verify=False)
    r.encoding = 'utf-8'
    return r
def main():
    r = getlink('https://api-gw.bunchatv2.com/sport/matches?status=100&withfollow=binhluan').json()['data']
    for k in r:
        match_time = k['match_time'].split('.')[0]
        t = strptime(match_time, "%Y-%m-%dT%H:%M:%S")
        timestamp = mktime(t) + 7 * 3600
        t_local = localtime(timestamp)
        formatted = strftime("%H:%M", t_local)
        league = k['league']['name']
        home_team = k['home_team']['name']
        away_team = k['away_team']['name']
        category = k['category']['name']
        binhluan_follows = k['binhluan_follows']
        tentran = f'{formatted} {category} {league} | [COLOR yellow]{home_team} vs {away_team}[/COLOR]'
        for m in binhluan_follows:
            data = m['data']
            if data:
                flv = data['stream_links']['flv']
                user = m['user']['fullname']
                tenm = f'{tentran} | {user}'
                addDir(tenm, 'play', id=flv)
        stream_links = k['stream_links']
        if stream_links:
            for n in stream_links:
                link = n['link']
                tenm = f'{tentran} | Nhà đài'
                addDir(tenm, 'play', id=link)
    endOfDirectory(HANDLE)
def play(idp):
    linkplay = re.sub(r'\s+', '%20', idp.strip(), flags=re.UNICODE)
    hdr = f'verifypeer=false&User-Agent={unquote(UA)}&Referer=https://bunchatv2.com/'
    if 'm3u8' in linkplay:
        play_item = ListItem(offscreen=True, path=linkplay)
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
        play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
    else:
        play_item = ListItem(offscreen=True, path=f'{linkplay}|{hdr}')
    setResolvedUrl(HANDLE, True, listitem=play_item)
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action_map = {
        'play': partial(play, params.get('id')),
    }
    action_map.get(params.get('mode'), main)()
try:
    router(argv[2][1:])
except:
    pass