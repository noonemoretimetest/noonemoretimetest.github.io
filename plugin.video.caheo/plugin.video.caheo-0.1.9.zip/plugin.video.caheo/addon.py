from urllib.parse import urlencode, parse_qsl, unquote
from functools import partial
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
import re, sys, requests, xbmcgui
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
ICON = Addon().getAddonInfo('icon')
UA = 'Mozilla/5.0 (Linux; Android 16; Pixel 9 Pro Build/AP4A.261212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/605.1.15 EdgA/140.0.0.0'
def addDir(title, mode, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=f'{title}')
    list_item.setArt({'icon': ICON, 'thumb': ICON, 'poster': ICON, 'fanart': ICON})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(f'{title}')
    info_tag.setPlot(f'{title}')
    setContent(HANDLE, 'videos')
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url):
    r = requests.get(url, timeout=20, headers={'user-agent': UA, 'referer': url.encode('utf-8')})
    r.encoding = 'utf-8'
    return r
def main():
    kq = getlink('https://api.rkdata.xyz/v1/caheo/home.html').json()['data']['lives']
    for v in kq:
        for k in v['matchs']:
            timeOnly = k['timeOnly']
            home = k['home']['name']
            away = k['away']['name']
            blv = k['blv']['name']
            tenm = f'{timeOnly} {home} vs {away} | {blv}' if blv else f'{timeOnly} {home} vs {away}'
            addDir(tenm, 'list_caheo', idck=k['id'], name=tenm)
    endOfDirectory(HANDLE)
def list_caheo(tentran, idck):
    r = getlink(f'https://api.rkdata.xyz/v1/caheo/match-{idck}.html').json()['data']['links']
    for k in r:
        if k['url']:
            ten = f'{tentran} | {k["name"]}'
            addDir(ten, 'play', id=k['url'], is_folder=False)
    endOfDirectory(HANDLE)
def play(idp):
    linkplay = re.sub(r'\s+', '%20', idp.strip(), flags=re.UNICODE)
    hdr = f'verifypeer=false&User-Agent={unquote(UA)}&Referer=https://watch.rkplayer.xyz/'
    play_item = xbmcgui.ListItem(offscreen=True)
    if 'm3u8' in linkplay:
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
        play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
    else:
        linkplay = f'{linkplay}|{hdr}'
    play_item.setPath(linkplay)
    setResolvedUrl(HANDLE, True, listitem=play_item)
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action_map = {
        'list_caheo': partial(list_caheo, params.get('name'), params.get('idck')),
        'play': partial(play, params.get('id')),
    }
    action_map.get(params.get('mode'), main)()
try:
    router(sys.argv[2][1:])
except:
    pass